import Mathlib
import PEqualNP.Defs

namespace PetersenReaders

/-- The edge function from the project assignment, with its vertex numbering. -/
def edge (x : Fin 10 → Bool) : Bool := (x 0 && x 1) || (x 1 && x 2) || (x 2 && x 3) || (x 3 && x 4) || (x 4 && x 0) || (x 0 && x 5) || (x 1 && x 6) || (x 2 && x 7) || (x 3 && x 8) || (x 4 && x 9) || (x 5 && x 7) || (x 7 && x 9) || (x 9 && x 6) || (x 6 && x 8) || (x 8 && x 5)

def pair (p q : Fin 10) : Fin 10 → Bool := fun i => decide (i = p ∨ i = q)

/-- Each entry encodes a set that witnesses dependence on v with p and q selected. -/
private def masks : Array Nat := #[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 10, 18, 34, 0, 130, 258, 514,
    0, 0, 20, 0, 20, 36, 84, 0, 276, 548, 0, 10, 0, 10, 0, 40, 104, 138, 0, 522,
    0, 18, 20, 0, 16, 48, 80, 144, 272, 0, 0, 34, 36, 40, 48, 32, 96, 0, 0, 544,
    0, 0, 84, 104, 80, 96, 80, 208, 0, 0, 0, 130, 0, 138, 144, 0, 208, 130, 386, 0,
    0, 258, 276, 0, 272, 0, 0, 386, 258, 770, 0, 514, 548, 522, 0, 544, 0, 0, 770, 514,
    1, 0, 5, 9, 0, 0, 65, 129, 257, 513, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    5, 0, 4, 0, 20, 36, 68, 0, 260, 516, 9, 0, 0, 9, 0, 104, 72, 137, 0, 521,
    0, 0, 20, 0, 20, 52, 80, 208, 276, 0, 0, 0, 36, 104, 52, 36, 96, 0, 0, 548,
    65, 0, 68, 72, 80, 96, 64, 192, 0, 0, 129, 0, 0, 137, 208, 0, 192, 129, 385, 0,
    257, 0, 260, 0, 276, 0, 0, 385, 257, 769, 513, 0, 516, 521, 0, 548, 0, 0, 769, 513,
    9, 0, 0, 9, 0, 0, 73, 129, 385, 521, 0, 2, 0, 10, 18, 34, 0, 130, 258, 514,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 10, 0, 8, 0, 40, 72, 136, 0, 520,
    0, 18, 0, 0, 18, 50, 208, 144, 274, 0, 0, 34, 0, 40, 50, 34, 104, 0, 0, 546,
    73, 0, 0, 72, 208, 104, 72, 192, 0, 0, 129, 130, 0, 136, 144, 0, 192, 128, 384, 0,
    385, 258, 0, 0, 274, 0, 0, 384, 258, 770, 521, 514, 0, 520, 0, 546, 0, 0, 770, 514,
    5, 0, 5, 0, 0, 0, 69, 385, 257, 517, 0, 18, 0, 0, 18, 50, 0, 146, 258, 770,
    5, 0, 4, 0, 20, 36, 68, 0, 260, 516, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 18, 20, 0, 16, 48, 80, 144, 272, 0, 0, 50, 36, 0, 48, 36, 100, 0, 0, 548,
    69, 0, 68, 0, 80, 100, 68, 208, 0, 0, 385, 146, 0, 0, 144, 0, 208, 144, 384, 0,
    257, 258, 260, 0, 272, 0, 0, 384, 256, 768, 517, 770, 516, 0, 0, 548, 0, 0, 768, 516,
    1, 0, 5, 9, 0, 0, 65, 129, 257, 513, 0, 10, 0, 10, 0, 42, 0, 138, 770, 514,
    5, 0, 5, 0, 0, 548, 69, 0, 261, 516, 9, 10, 0, 8, 0, 40, 72, 136, 0, 520,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 548, 40, 0, 40, 104, 0, 0, 544,
    65, 0, 69, 72, 0, 104, 65, 193, 0, 0, 129, 138, 0, 136, 0, 0, 193, 129, 385, 0,
    257, 770, 261, 0, 0, 0, 0, 385, 257, 768, 513, 514, 516, 520, 0, 544, 0, 0, 768, 512,
    1, 0, 5, 9, 0, 0, 65, 129, 257, 513, 0, 130, 0, 138, 146, 0, 0, 130, 258, 770,
    5, 0, 5, 0, 276, 0, 69, 0, 260, 517, 9, 138, 0, 9, 0, 0, 73, 136, 0, 521,
    0, 146, 276, 0, 144, 0, 208, 144, 272, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    65, 0, 69, 73, 208, 0, 65, 192, 0, 0, 129, 130, 0, 136, 144, 0, 192, 128, 384, 0,
    257, 258, 260, 0, 272, 0, 0, 384, 256, 768, 513, 770, 517, 521, 0, 0, 0, 0, 768, 513,
    257, 0, 261, 521, 0, 0, 0, 385, 257, 513, 0, 2, 0, 10, 18, 34, 0, 130, 258, 514,
    261, 0, 260, 0, 276, 548, 0, 0, 260, 516, 521, 10, 0, 10, 0, 42, 0, 138, 0, 520,
    0, 18, 276, 0, 18, 50, 0, 146, 272, 0, 0, 34, 548, 42, 50, 34, 0, 0, 0, 544,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 385, 130, 0, 138, 146, 0, 0, 130, 384, 0,
    257, 258, 260, 0, 272, 0, 0, 384, 256, 768, 513, 514, 516, 520, 0, 544, 0, 0, 768, 512,
    5, 0, 5, 521, 0, 0, 69, 0, 261, 513, 0, 34, 0, 42, 50, 34, 0, 0, 770, 514,
    5, 0, 4, 0, 20, 36, 68, 0, 260, 516, 521, 42, 0, 40, 0, 40, 104, 0, 0, 520,
    0, 50, 20, 0, 20, 48, 84, 0, 276, 0, 0, 34, 36, 40, 48, 32, 96, 0, 0, 544,
    69, 0, 68, 104, 84, 96, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    261, 770, 260, 0, 276, 0, 0, 0, 260, 768, 513, 514, 516, 520, 0, 544, 0, 0, 768, 512,
    9, 0, 69, 9, 0, 0, 65, 137, 0, 521, 0, 10, 0, 10, 50, 34, 0, 138, 0, 522,
    69, 0, 36, 0, 52, 36, 68, 0, 0, 548, 9, 10, 0, 8, 0, 40, 72, 136, 0, 520,
    0, 50, 52, 0, 48, 48, 80, 208, 0, 0, 0, 34, 36, 40, 48, 32, 96, 0, 0, 544,
    65, 0, 68, 72, 80, 96, 64, 192, 0, 0, 137, 138, 0, 136, 208, 0, 192, 136, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 521, 522, 548, 520, 0, 544, 0, 0, 0, 520,
    65, 0, 69, 73, 0, 0, 65, 129, 385, 0, 0, 18, 0, 138, 18, 50, 0, 130, 274, 0,
    69, 0, 20, 0, 20, 52, 68, 0, 276, 0, 73, 138, 0, 72, 0, 104, 72, 136, 0, 0,
    0, 18, 20, 0, 16, 48, 80, 144, 272, 0, 0, 50, 52, 104, 48, 48, 96, 0, 0, 0,
    65, 0, 68, 72, 80, 96, 64, 192, 0, 0, 129, 130, 0, 136, 144, 0, 192, 128, 384, 0,
    385, 274, 276, 0, 272, 0, 0, 384, 272, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

private def input (v p q : Fin 10) (i : Fin 10) : Bool :=
  (masks[v.val * 100 + p.val * 10 + q.val]!).testBit i.val

private def setBit (x : Fin 10 → Bool) (v : Fin 10) (b : Bool) : Fin 10 → Bool :=
  fun i => if i = v then b else x i

private theorem inputs_valid : ∀ v p q : Fin 10, v ≠ p → v ≠ q → edge (pair p q) = false →
    let x := input v p q
    x v = false ∧ x p = true ∧ x q = true ∧ edge x = false ∧ edge (setBit x v true) = true := by
  decide +kernel

/-- Selecting one or two independent partners still leaves the target sensitive to v. -/
theorem selected_partners (v p q : Fin 10) (hp : v ≠ p) (hq : v ≠ q)
    (hi : edge (pair p q) = false) :
    ∃ x : Fin 10 → Bool, x v = false ∧ x p = true ∧ x q = true ∧
      edge x = false ∧ edge (Function.update x v true) = true := by
  have agree (z : Fin 10 → Bool) : setBit z v true = Function.update z v true := by
    funext i
    by_cases h : i = v <;> simp [setBit,Function.update,h]
  obtain ⟨a,b,c,d,e⟩ := inputs_valid v p q hp hq hi
  exact ⟨_,a,b,c,d,(agree _ ▸ e)⟩

/-- The rest of a circuit cannot recover the edge function if these are its only two
observations of input v. Taking p = q also covers a single raw OR reader. -/
theorem no_two_or_readers (v p q : Fin 10) (hp : v ≠ p) (hq : v ≠ q)
    (hi : edge (pair p q) = false) :
    ¬ ∃ h : (Fin 10 → Bool) → Bool → Bool → Bool, ∀ x,
      edge x = h (Function.update x v false) (x v || x p) (x v || x q) := by
  rintro ⟨h, hh⟩
  obtain ⟨x, hv, hxp, hxq, h0, h1⟩ := selected_partners v p q hp hq hi
  have a := hh x
  have b := hh (Function.update x v true)
  simp [h0, hxp, hxq] at a
  simp [h1, Function.update_idem] at b
  exact Bool.false_ne_true (a.symm.trans b)

open PEqualNP.CircuitLowerBounds

private def step (w : List Bool) (g : Gate) : List Bool :=
  w ++ [g.op.eval (g.inputs.map fun k => w.getD k false)]

private theorem get_raw (x : Fin 10 → Bool) (t : List Bool) (i : Fin 10) :
    (List.ofFn x ++ t).getD i.val false = x i := by
  rw [List.getD_append _ _ _ _ (by simp),
    List.getD_eq_getElem _ _ (by simp)]
  exact List.getElem_ofFn _

private theorem away (x y : Fin 10 → Bool) (v : Fin 10)
    (heq : ∀ i ≠ v, x i = y i) (t : List Bool) (k : Nat) (hk : k ≠ v.val) :
    (List.ofFn x ++ t).getD k false = (List.ofFn y ++ t).getD k false := by
  by_cases h : k < 10
  · let i : Fin 10 := ⟨k,h⟩
    exact (get_raw x t i).trans ((heq i (by intro e; exact hk (congrArg Fin.val e))).trans
      (get_raw y t i).symm)
  · rw [List.getD_append_right _ _ _ _ (by simp; omega),
        List.getD_append_right _ _ _ _ (by simp; omega)]
    simp

/-- A direct reader of v sees an OR with p or q. Other gates may use any project operation. -/
def onlyOrReaders (v p q : Fin 10) (g : Gate) : Prop :=
  v.val ∈ g.inputs → g.op = .or ∧ (p.val ∈ g.inputs ∨ q.val ∈ g.inputs)

private theorem same_step (x y : Fin 10 → Bool) (v p q : Fin 10)
    (heq : ∀ i ≠ v, x i = y i) (hp : x p = true ∧ y p = true)
    (hq : x q = true ∧ y q = true) (t : List Bool) (g : Gate)
    (hr : onlyOrReaders v p q g) :
    g.op.eval (g.inputs.map fun k => (List.ofFn x ++ t).getD k false) =
    g.op.eval (g.inputs.map fun k => (List.ofFn y ++ t).getD k false) := by
  by_cases hv : v.val ∈ g.inputs
  · obtain ⟨op, h⟩ := hr hv
    have on (z : Fin 10 → Bool) (hzp : z p = true) (hzq : z q = true) :
        g.op.eval (g.inputs.map fun k => (List.ofFn z ++ t).getD k false) = true := by
      rw [op]
      apply List.any_eq_true.mpr
      obtain h | h := h
      · exact ⟨true,List.mem_map.mpr ⟨p.val,h,(get_raw z t p).trans hzp⟩,rfl⟩
      · exact ⟨true,List.mem_map.mpr ⟨q.val,h,(get_raw z t q).trans hzq⟩,rfl⟩
    exact (on x hp.1 hq.1).trans (on y hp.2 hq.2).symm
  · apply congrArg g.op.eval
    apply List.map_congr_left
    intro i hi
    exact away x y v heq t i (by rintro rfl; exact hv hi)

private theorem same_tail (x y : Fin 10 → Bool) (v p q : Fin 10)
    (heq : ∀ i ≠ v, x i = y i) (hp : x p = true ∧ y p = true)
    (hq : x q = true ∧ y q = true) (gs : List Gate)
    (hr : ∀ g ∈ gs, onlyOrReaders v p q g) (t : List Bool) :
    ∃ u : List Bool, gs.foldl step (List.ofFn x ++ t) = List.ofFn x ++ u ∧
      gs.foldl step (List.ofFn y ++ t) = List.ofFn y ++ u := by
  induction gs generalizing t with
  | nil => exact ⟨t,rfl,rfl⟩
  | cons g gs ih =>
    have h := same_step x y v p q heq hp hq t g (hr g (by simp))
    simp only [List.foldl_cons,step,List.append_assoc]
    rw [h]
    exact ih (fun g hg => hr g (by simp [hg])) _

/-- A circuit whose only direct readers of v are the indicated OR gates cannot
compute the Petersen edge function when p and q form an independent set. -/
theorem circuit_reader_obstruction (C : Circuit) (v p q : Fin 10) (hp : v ≠ p) (hq : v ≠ q)
    (hi : edge (pair p q) = false) (hr : ∀ g ∈ C.gates, onlyOrReaders v p q g) :
    ¬ ∀ x : Fin 10 → Bool, C.eval (List.ofFn x) = edge x := by
  intro hc
  have same (x y : Fin 10 → Bool) (he : ∀ i ≠ v, x i = y i) (px : x p = true ∧ y p = true)
      (qx : x q = true ∧ y q = true) :
      ∃ t, C.wires (List.ofFn x) = List.ofFn x ++ t ∧ C.wires (List.ofFn y) = List.ofFn y ++ t := by
    change ∃ t, C.gates.foldl step (List.ofFn x) = List.ofFn x ++ t ∧
      C.gates.foldl step (List.ofFn y) = List.ofFn y ++ t
    simpa only [List.append_nil] using same_tail x y v p q he px qx C.gates hr []
  obtain ⟨x, hx, xp, xq, e0, e1⟩ := selected_partners v p q hp hq hi
  let y := Function.update x v true
  have he (i : Fin 10) (h : i ≠ v) : x i = y i := by simp [y,Function.update_of_ne h]
  have px : x p = true ∧ y p = true := ⟨xp,(he p (Ne.symm hp)).symm.trans xp⟩
  have qx : x q = true ∧ y q = true := ⟨xq,(he q (Ne.symm hq)).symm.trans xq⟩
  obtain ⟨t,tx,ty⟩ := same x y he px qx
  by_cases ho : C.output = v.val
  · let z : Fin 10 → Bool := fun _ => true
    let z' : Fin 10 → Bool := Function.update z v false
    have zz (i : Fin 10) (h : i ≠ v) : z i = z' i := by simp [z',Function.update_of_ne h]
    obtain ⟨u,_,hz⟩ := same z z' zz ⟨rfl,by simp [z',z,Function.update_of_ne (Ne.symm hp)]⟩
      ⟨rfl,by simp [z',z,Function.update_of_ne (Ne.symm hq)]⟩
    have eqn := hc z'
    rw [Circuit.eval,hz,ho,get_raw] at eqn
    have large : ∀ w : Fin 10, edge (Function.update (fun _ : Fin 10 => true) w false) = true := by
      decide +kernel
    simp [z',z,large] at eqn
  · have d := away x y v he t C.output ho
    rw [← tx,← ty] at d
    change C.eval (List.ofFn x) = C.eval (List.ofFn y) at d
    rw [hc,hc,e0] at d
    exact Bool.false_ne_true (d.trans e1)

end PetersenReaders
