# First gates of an 18-binary-gate circuit for the Petersen edge function

The 10-input function in L-meta-651 detects whether the selected vertices contain a Petersen edge. The binary circuit search grants free complementation on every wire. A circuit with one ordinary NOT and 19 gates would use 18 binary gates in this model.

The exhaustive results exclude every signed first gate except the OR of two nonadjacent vertices. Any gate that reads two original inputs can be moved to the beginning. Thus the restriction applies to every such gate in a minimum 18-binary-gate circuit. The search for circuits using only the surviving raw-input pairs is a separate computation.

## Reproduction

Run `python3 replay_nine.py --adjacent` with Python 3.10 or later and a C++20 compiler. It rebuilds the solvers and smaller bounds in a temporary directory, verifies a 16-gate witness after one vertex deletion, and checks the indicated first-gate cases. The longest single computation took about 11 minutes on the development machine. Run `python3 replay18.py` for the lower bound of 18 binary gates on the full graph.

## Why the adjacent-pair exclusion works

Fixing any one input to zero leaves a graph with exact binary complexity 16. On this nine-vertex graph, the computation also ruled out a size-16 circuit that begins with the raw OR of vertices 1 and 2. Vertex 0 is the deleted vertex in this numbering. The same exclusion holds for all images under automorphisms fixing vertex 0.

If an original raw first gate survives a vertex deletion, the reduced circuit still contains that gate. The restriction algorithm can retain the designated first gate even if its output becomes unused. A circuit with a dead gate at the minimum size would give a circuit below the minimum after deleting that gate. Consequently a cofactor in the excluded first-gate class needs at least 17 gates if that gate is retained. The eight-vertex cofactor profiles are used in the same way after a two-vertex deletion. The direct search using these bounds excluded the adjacent OR in 1,230,833 states. Six other signed first-gate cases terminated at their initial states.

These are computational lower bounds outside Lean. The Lean sources in this archive establish the upper witnesses and a restriction on OR readers independently. In the latter theorem, if p and q are selected and form an independent set, the edge function can still depend on a third input v. An OR reader with either selected partner always outputs true. Lean proves that a circuit with only such direct readers of v cannot compute the function. The theorem also covers p equal to q.
