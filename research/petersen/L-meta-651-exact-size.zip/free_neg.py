"""Exact binary-gate search with free complementation on the Petersen graph."""
import sys
from functools import lru_cache
from itertools import combinations, product
from time import monotonic

E=((0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5))
P=[1<<a|1<<b for a,b in E]
def edge(x):return any((x&e)==e for e in P)
neg=[x for x in range(1024) if not edge(x)]
maximal=[x for x in neg if all(edge(x|1<<i) for i in range(10) if not x>>i&1)]
pairs=list(dict.fromkeys([*product(P,maximal),*((x|1<<j,x) for x in neg for j in range(10) if edge(x|1<<j))]))
k=len(pairs); mask=(1<<k)-1; full=(1<<(2*k))-1
def canon(x):return min(x,x^full)
raw=tuple(canon(sum((((p>>i&1)<<k)|(n>>i&1)) <<j for j,(p,n) in enumerate(pairs))) for i in range(10))
target=canon(mask<<k)
@lru_cache(maxsize=150000)
def sep(x):return ((x>>k)^x)&mask
@lru_cache(maxsize=150000)
def hit(v,b):
    if target in v:return True
    if len(v)>b+1 or b==0:return False
    return any(hit(w,b-1) for w in children(v,b))
def children(v,b,first=False):
    for i,j in combinations(range(len(v)),2):
        if first and i==0 and j in (1,2):pass
        elif first:continue
        a,h=v[i],v[j]
        rest=v[:i]+v[i+1:j]+v[j+1:]
        other=0
        for z in rest:other|=sep(z)
        for out in set(canon(x&y) for x in (a,full^a) for y in (h,full^h)):
            if out==0 or out in v:continue
            covered=other|sep(out)
            for keep in ((),(a,),(h,),(a,h)):
                if len(rest)+len(keep)+1>b:continue
                cov=covered
                for z in keep:cov|=sep(z)
                if cov==mask:yield tuple(sorted((*rest,*keep,out)))
def symmetry_check():
    adj={tuple(sorted(e)) for e in E}
    def visit(p):
        if len(p)==10:yield tuple(p);return
        i=len(p)
        for j in range(10):
            if j not in p and all(((k,i) in adj)==(tuple(sorted((p[k],j))) in adj) for k in range(i)):
                yield from visit([*p,j])
    autos=list(visit([]))
    assert len(autos)==120
    assert {tuple(sorted((a[0],a[j]))) for a in autos for j in (1,2)}==set(combinations(range(10),2))

if __name__=='__main__':
    symmetry_check()
    for b in map(int,sys.argv[1:]):
        start=monotonic()
        roots=set(children(raw,b,first=True))
        result=any(hit(w,b-1) for w in roots)
        print(b,len(pairs),len(roots),result,hit.cache_info(),round(monotonic()-start,3),flush=True)
        hit.cache_clear();sep.cache_clear()
