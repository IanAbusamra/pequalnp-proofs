"""Replay the exact lower and upper bounds after removing vertex 0."""
from pathlib import Path
from itertools import combinations
import json,re,shutil,subprocess,sys,tempfile
from cofactors import automorphisms,core,orbit
src=Path(__file__).resolve().parent

def validate_witness():
    rows=[tuple(map(int,s.split())) for s in (src/'nine-witness.txt').read_text().splitlines()]
    assert len(rows)==16
    edges=core(1022)[1]
    for x in range(1024):
        values=[bool(x>>i&1) for i in range(10)]
        for out,a,b,sign in rows:
            assert out==len(values) and 0<=a<out and 0<=b<out and sign in (0,3)
            values.append((values[a] and values[b]) if sign==0 else (values[a] or values[b]))
        assert values[-1]==any((x>>a)&(x>>b)&1 for a,b in edges)
    print('Verified the 16-gate monotone witness on all 1024 assignments.',flush=True)

if __name__=='__main__':
    validate_witness()
    autos=automorphisms()
    with tempfile.TemporaryDirectory() as directory:
        tmp=Path(directory)
        for name in ['more_small','root_profiles','seven_profiles','conditioned','cofactors','free_neg']:
            shutil.copyfile(src/(name+'.py'),tmp/(name+'.py'))
        for name in ['subgraph','bounded']:
            subprocess.run(['c++','-O3','-std=c++20',src/(name+'.cpp'),'-o',tmp/name],check=True)
        def stage(name):
            subprocess.run([sys.executable,tmp/(name+'.py')],check=True)
        stage('more_small')
        bounds={int(k):v for k,v in json.loads((tmp/'lower-small.json').read_text()).items()}
        for mask in (1020,1018,1022):
            path=tmp/f'cuts-{mask}.txt'
            verts=[v for v in range(10) if mask>>v&1]
            with path.open('w') as f:
                for n in (1,2):
                    for vs in combinations(verts,n):
                        cut=sum(1<<v for v in vs);lb=bounds[mask^cut]
                        if lb>0:print(cut,lb,file=f)
            if mask==1022:break
            k={1020:12,1018:11}[mask]
            out=subprocess.check_output([tmp/'bounded',str(k),str(mask),path,'free'],text=True)
            print(out.splitlines()[0],flush=True)
            assert re.search(r'found 0\b',out)
            for m in orbit(mask,autos):bounds[m]=k+1
        for name in ('root_profiles','seven_profiles','conditioned'):stage(name)
        result=json.loads((tmp/'profile-1022-at15.json').read_text())
        assert len(result)==144 and set(result.values())=={16}
        print('Deleting a Petersen vertex gives exact binary gate complexity 16, even with free negation.',flush=True)
        if '--adjacent' in sys.argv[1:]:
            shutil.copyfile(src/'adjacent_stage.py',tmp/'adjacent_stage.py')
            subprocess.run(['c++','-O3','-std=c++20',src/'anchoredfree.cpp','-o',tmp/'anchoredfree'],check=True)
            stage('adjacent_stage')

        if '--monotone' in sys.argv[1:]:
            for name in ('partial','boundary','anchored'):
                shutil.copyfile(src/(name+'.cpp'),tmp/(name+'.cpp'))
                subprocess.run(['c++','-O3','-std=c++20',tmp/(name+'.cpp'),'-o',tmp/name],check=True)
            for name in ('matchings','mono_anchors','pair_profiles','pair_full','monotone_stage'):
                shutil.copyfile(src/(name+'.py'),tmp/(name+'.py'))
            stage('monotone_stage')

        if '--final' in sys.argv[1:]:
            assert '--adjacent' in sys.argv[1:]
            for name in ('dynamic_roots','full_stage'):
                shutil.copyfile(src/(name+'.py'),tmp/(name+'.py'))
            for name in ('freesplit','exactpair'):
                subprocess.run(['c++','-O3','-std=c++20',src/(name+'.cpp'),'-o',tmp/name],check=True)
            shutil.copytree(src/'final-inputs',tmp/'final-inputs')
            stage('full_stage')
