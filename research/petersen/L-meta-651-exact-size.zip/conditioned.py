"""Cofactor bounds when a designated first binary gate survives deletion."""
from pathlib import Path
from itertools import combinations
from functools import cache
import json,re,subprocess
from root_profiles import translate
from cofactors import automorphisms,core
q=Path(__file__).resolve().parent; autos=automorphisms()
def image(mask,p):
    return sum(((mask>>i)&1)<<p[i] for i in range(10))
@cache
def canonical(mask):
    return min((image(mask,p),tuple(p)) for p in autos)
@cache
def profile(mask):
    return json.loads((q/f'profile-{mask}.json').read_text())
def bound(mask,cut,base,root):
    i,j,_=root
    if cut & ((1<<i)|(1<<j)):return base
    vs,_=core(mask^cut)
    if i not in vs or j not in vs:return base+1
    rep,p=canonical(mask^cut)
    # The two eight-vertex representatives use deleted pairs (0,1) and (0,2);
    # their masks are not the numerically least elements of their orbits.
    if (mask^cut).bit_count()==8:
        for rep in (1020,1018):
            p=next((p for p in autos if image(mask^cut,p)==rep),None)
            if p is not None:break
    label=','.join(map(str,translate(root,p)))
    val=profile(rep)[label]
    assert val in (base,base+1)
    return val
def main():
    m=1022; base=[tuple(map(int,l.split())) for l in (q/f'cuts-{m}.txt').read_text().splitlines()]
    vs,_=core(m)
    roots={(*e,s) for e in combinations(vs,2) for s in range(4)}
    orbit_group=[g for g in autos if image(m,g)==m]
    results={}
    while roots:
        r=min(roots);o={translate(r,g) for g in orbit_group};roots-=o
        f=q/('anchor-nine-'+'-'.join(map(str,r))+'.txt')
        f.write_text(''.join(f'{c} {bound(m,c,b,r)}\n' for c,b in base))
        with (q/('anchor-nine-'+'-'.join(map(str,r))+'.log')).open('w') as log:
            subprocess.run([q/'bounded','15',str(m),f,'free',*map(str,r)],text=True,stdout=log,check=True)
        msg=log.name
        result=Path(msg).read_text()
        found=int(re.search(r'found ([01])',result)[1])
        print(result.splitlines()[0],flush=True)
        for t in o:results[','.join(map(str,t))]=16-found
        (q/'profile-1022-at15.json').write_text(json.dumps(results,sort_keys=True))
        if found:break
if __name__=='__main__':main()
