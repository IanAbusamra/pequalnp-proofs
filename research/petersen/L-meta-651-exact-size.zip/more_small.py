from cofactors import orbit, automorphisms, core
from itertools import combinations
from pathlib import Path
import subprocess,re,json
q=Path(__file__).resolve().parent
autos=automorphisms()
def upper(mask):
    vs,edges=core(mask)
    if not edges:return 0
    tau=next(t for t in range(len(vs)+1) if any(all(a in C or b in C for a,b in edges) for C in combinations(vs,t)))
    return len(edges)+tau-1

groups={sum(1<<v for v in S) for n in (5,6,7) for S in combinations(range(10),n)}
results={}
while groups:
    mask=min(groups);orb=orbit(mask,autos);groups-=orb
    vs,_=core(mask);ub=upper(mask)
    lb=len(vs)-1
    for k in range(ub-1,lb-1,-1):
        p=subprocess.run([q/'subgraph',str(k),str(mask)],capture_output=True,text=True,check=True)
        print(p.stdout.strip(),flush=True)
        ok=re.search(r'found ([01]),',p.stdout)
        assert ok
        if ok[1]=='0':lb=k+1;break
    for m in orb:results[m]=lb
    print('CLASS',mask,len(orb),lb,ub,flush=True)
(q/'lower-small.json').write_text(json.dumps(results,sort_keys=True))
