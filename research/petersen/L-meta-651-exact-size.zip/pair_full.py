from functools import cache
from itertools import combinations
from pathlib import Path
import subprocess,json,re
from cofactors import E,automorphisms,core
from root_profiles import translate
from conditioned import image,bound
from mono_anchors import unchanged
q=Path(__file__).resolve().parent
root=(0,2,3); autos=automorphisms();edges={tuple(sorted(e)) for e in E}

def src():
 s=(q/'anchored.cpp').read_text().replace('Word all_cuts=0;', 'int second_a=-1,second_b=-1;\nWord all_cuts=0;')
 s=s.replace('if(argc!=6 && argc!=9)', 'if(argc!=11)').replace('if(argc==9)', 'if(argc==11)')
 s=s.replace('  auto start=std::chrono','  second_a=std::stoi(argv[9]);second_b=std::stoi(argv[10]);\n  auto start=std::chrono')
 x='    if(budget==binary_budget && first_a>=0 && (a!=first_a || b!=first_b)) continue;'
 s=s.replace(x,x+'''
    if(a<10 && b<10) {
      // A circuit containing a raw OR on a Petersen edge is already excluded.
      bool edge=false;
      for(auto [u,v]:edges) if((a==u && b==v) || (a==v && b==u)) edge=true;
      if(edge || (budget<binary_budget && second_a<0)) continue;
    }
    if(budget==binary_budget-1 && second_a>=0 && (a!=second_a || b!=second_b)) continue;''')
 s=s.replace('if(n) needed[0]=all_cuts;', 'if(n) needed[0]=all_cuts;\n  if(n>1 && second_a>=0) needed[1]=all_cuts;')
 s=s.replace('int last_new=(budget==binary_budget && first_a>=0)?-1:c;', 'int last_new=budget>=binary_budget-(second_a>=0)?-1:c;')
 (q/'pairfull.cpp').write_text(s)

@cache
def profile(m):
 s=json.loads((q/('mono-root-profile.json' if m==1022 else f'profile-{m}.json')).read_text())
 pairs=json.loads((q/f'mono-pairs-{m}.json').read_text())
 return s,pairs
@cache
def canon(m):
 return next((v,p) for v in [1022,1020,1018] for p in autos if image(m,p)==v)
@cache
def boundary(m):
 ed=[(1<<i)|(1<<j) for i,j in core(m)[1]]
 negatives={x for x in range(1024) if not(x&~m) and not any(x&e==e for e in ed)}
 maximal=[x for x in negatives if all((x|1<<v) not in negatives for v in range(10) if m&(1<<v) and not x&(1<<v))]
 return ed,maximal

def retained(cut,r,earlier=None):
 if not unchanged(1023,cut,r):return False
 if earlier is None:return True
 a=sum(1<<v for v in r[:2]);b=sum(1<<v for v in earlier[:2])
 pos,neg=boundary(1023^cut)
 dominates=all(not(x&a) or x&b for x in pos) and all(not(x&b) or x&a for x in neg)
 return not dominates

def cuts(second):
 baseline=[tuple(map(int,l.split())) for l in (q/'mono-cuts-1023.txt').read_text().splitlines()]
 out=[]; roots=[root] if second is None else [root,second]
 for cut,lb in baseline:
    m,p=canon(1023^cut);ps,pp=profile(m);survive=[]
    for i,r in enumerate(roots):
        if retained(cut,r,None if not i else root):
            rr=translate(r,p)
            if any(v not in core(m)[0] for v in rr[:2]):
                survive.append((rr,False))
            else:survive.append((rr,ps[','.join(map(str,rr))]==lb))
    bump=any(not good for _,good in survive)
    if len(survive)==2 and not bump:
        key=';'.join(','.join(map(str,r)) for r in sorted(r for r,_ in survive))
        assert key in pp
        bump=not pp[key]
    out.append((cut,lb+int(bump)))
 label='solo' if second is None else '-'.join(map(str,second[:2]))
 path=q/f'pairfull-{label}.txt';path.write_text(''.join(f'{c} {b}\n' for c,b in out))
 return label,path,sum(b0<b1 for (_,b0),(_,b1) in zip(baseline,out))

def main():
 src();subprocess.run(['c++','-O3','-std=c++20',q/'pairfull.cpp','-o',q/'pairfull'],check=True)
 pairs={(*s,3) for s in combinations(range(10),2) if s not in edges}
 todo=set(combinations(sorted(pairs),2));work=[]
 while todo:
    rs=min(todo);orb={tuple(sorted(translate(r,p) for r in rs)) for p in autos};todo-=orb
    b=min(next(t for t in pair if t!=root) for pair in orb if root in pair)
    label,path,score=cuts(b);work.append((score,b,label,path,len(orb)))
 label,path,score=cuts(None);work=[(score,None,label,path,1)]+sorted(work,reverse=True)
 for score,b,label,path,size in work:
    print('START',label,'cuts raised',score,'pairs in orbit',size,flush=True)
    with (q/f'pairfull-{label}.log').open('w') as f:
        subprocess.run([q/'pairfull','19','1023',path,'0','1','0','2','3',*map(str,b[:2] if b else [-1,-1])],stdout=f,check=True)
    txt=(q/f'pairfull-{label}.log').read_text();print(txt.splitlines()[0],flush=True)
    if 'found 1' in txt:return
if __name__=='__main__':main()
