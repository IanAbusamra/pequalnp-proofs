// Binary AND gates with arbitrary complemented edges generate AND/OR/NOT circuits.
// Each state records live truth tables on the entire ten-variable cube.
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using Table = std::array<uint64_t,16>;
using State = std::vector<int>;
struct TableHash {
  size_t operator()(const Table& t) const {
    uint64_t h=1; for (auto x : t) h=(h ^ x)*1099511628211ull; return h;
  }
};
struct StateHash {
  size_t operator()(const State& s) const {
    uint64_t h=1; for (auto x : s) h=(h ^ uint64_t(x+1))*1099511628211ull; return h;
  }
};
using Bits = std::array<uint64_t,10>;
struct Sample { Bits p{}, n{}, sep{}; };
std::vector<Sample> samples;
std::vector<std::pair<int,int>> pairs;
std::vector<Table> wires;
std::unordered_map<Table,int,TableHash> ids;
std::array<std::vector<std::pair<int,int>>,1024> conflicts;
std::vector<std::unordered_set<State,StateHash>> failed;
std::array<std::pair<int,int>,15> edges={{{0,1},{1,2},{2,3},{3,4},{4,0},{0,5},{1,6},{2,7},{3,8},{4,9},{5,7},{7,9},{9,6},{6,8},{8,5}}};
unsigned long long explored=0;
int target, root_budget, vertex_mask;
int lookup(Table t) {
  if (t[0]&1) for (auto& word:t) word=~word;
  auto [it,fresh]=ids.emplace(t,wires.size());
  if (fresh) {
    wires.push_back(t);
    Sample sm;
    for (size_t i=0;i<pairs.size();++i) {
      auto [p,n]=pairs[i];
      sm.p[i/64]|=((t[p/64]>>(p%64))&1ull)<<(i%64);
      sm.n[i/64]|=((t[n/64]>>(n%64))&1ull)<<(i%64);
    }
    for (int z=0;z<10;++z) sm.sep[z]=sm.p[z]^sm.n[z];
    samples.push_back(sm);
  }
  return it->second;
}
bool bit(int w,int x) { return (wires[w][x>>6]>>(x&63))&1; }
bool separable(const State& s) {
  int raw_mask=0;
  State built;
  for (int w:s) {
    if (w<10) raw_mask|=1<<w;
    else built.push_back(w);
  }
  for (auto [p,n]:conflicts[raw_mask]) {
    bool diff=false;
    for (int w:built) if (bit(w,p)!=bit(w,n)) {diff=true;break;}
    if (!diff) return false;
  }
  return true;
}
bool solve(const State& s,int budget) {
  if (std::binary_search(s.begin(),s.end(),target)) return true;
  if (!budget || int(s.size())>budget+1) return false;
  auto& memo=failed[budget];
  if (memo.contains(s)) return false;
  if (!separable(s)) return false;
  if (memo.size()<150000) memo.insert(s);
  ++explored;
  for (size_t i=0;i<s.size();++i) for (size_t j=i+1;j<s.size();++j) {
    
    State rest;
    for (size_t z=0;z<s.size();++z) if (z!=i && z!=j) rest.push_back(s[z]);
    Bits need;
    for(int z=0;z<10;++z) {
      int bits=std::clamp(int(pairs.size())-64*z,0,64);
      need[z]=bits==64 ? ~0ull : (1ull<<bits)-1;
    }
    for (int r:rest) for (int z=0;z<10;++z) need[z]&=~samples[r].sep[z];
    for (int inv=0;inv<4;++inv) {

      bool possible[4]={true,true,true,true};
      for (int z=0;z<10;++z) {
        auto p=(inv&1?~samples[s[i]].p[z]:samples[s[i]].p[z])&
          (inv&2?~samples[s[j]].p[z]:samples[s[j]].p[z]);
        auto n=(inv&1?~samples[s[i]].n[z]:samples[s[i]].n[z])&
          (inv&2?~samples[s[j]].n[z]:samples[s[j]].n[z]);
        auto miss=need[z]&~(p^n);
        if (miss) possible[0]=false;
        if (miss&~samples[s[i]].sep[z]) possible[1]=false;
        if (miss&~samples[s[j]].sep[z]) possible[2]=false;
      }
      bool viable=false;
      for (unsigned k=0;k<4;++k) viable|=possible[k] && int(rest.size())+1+std::popcount(k)<=budget;
      if (!viable) continue;
      // Complemented outputs are free, so De Morgan covers OR as well.
      Table t;
      for (int z=0;z<16;++z) {
        uint64_t a=wires[s[i]][z], b=wires[s[j]][z];
        t[z]=(inv&1?~a:a)&(inv&2?~b:b);
      }
      int c=lookup(t);
      if (c==10 || std::binary_search(s.begin(),s.end(),c)) continue;
      for (unsigned keep=0;keep<4;++keep) {
        if (!possible[keep] || int(rest.size())+1+std::popcount(keep)>budget) continue;
        State next=rest;
        next.push_back(c);
        if (keep&1) next.push_back(s[i]);
        if (keep&2) next.push_back(s[j]);
        std::sort(next.begin(),next.end());
        if (solve(next,budget-1)) return true;
      }
    }
  }
  return false;
}
int main(int argc,char** argv) {
  if (argc!=3) return 2;
  vertex_mask=std::atoi(argv[2]); if(vertex_mask<=0 || vertex_mask>=1024)return 2;
  root_budget=std::atoi(argv[1]);
  if (root_budget<1 || root_budget>19) return 2;
  std::array<Table,10> raw{}; Table goal{};
  std::vector<int> pos,neg;
  for (int x=0;x<1024;++x) {
    for (int i=0;i<10;++i) if ((x>>i)&1) raw[i][x>>6]|=1ull<<(x&63);
    bool truth=false;
    for (auto [a,b]:edges) if ((vertex_mask>>a)&(vertex_mask>>b)&1) truth|=((x>>a)&(x>>b)&1);
    if(truth) goal[x>>6]|=1ull<<(x&63);
    if(!(x&~vertex_mask)) (truth?pos:neg).push_back(x);
  }
  auto add=[&](int p,int n){
    if(std::find(pairs.begin(),pairs.end(),std::pair{p,n})==pairs.end()) pairs.emplace_back(p,n);
  };
  for(auto [a,b]:edges) if ((vertex_mask>>a)&(vertex_mask>>b)&1) for (int z:neg) {
    bool maximal=true;
    for(int j=0;j<10;++j) if (!(z&(1<<j)) && std::binary_search(neg.begin(),neg.end(),z|(1<<j))) maximal=false;
    if(maximal) add((1<<a)|(1<<b),z);
  }
  for(int z:neg) for(int j=0;j<10;++j)
    if (std::binary_search(pos.begin(),pos.end(),z|(1<<j))) add(z|(1<<j),z);
  if(pairs.size()>640 || pairs.empty())return 4;
  State first;
  int active=0;
  for(auto [a,b]:edges) if ((vertex_mask>>a)&(vertex_mask>>b)&1) active|=(1<<a)|(1<<b);
  for(int j=0;j<10;++j) {
    int id=lookup(raw[j]);
    if((active>>j)&1) first.push_back(id);
  }
  if (lookup(Table{})!=10) return 3;
  target=lookup(goal);
  for (int r=0;r<1024;++r)
    for(int n:neg) for (int p:pos) if (!((p^n)&r)) conflicts[r].emplace_back(p,n);
  failed.resize(root_budget+1);
  auto t=std::chrono::steady_clock::now();
  bool answer=solve(first,root_budget);
  std::cout<<"Binary budget "<<root_budget<<", vertices "<<vertex_mask<<", full cube, found "<<answer<<", states "<<explored
    <<", signals "<<wires.size()<<", seconds "<<std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count()<<"\n";
}
