"""Recompute all lower bounds used in the eighteen-binary-gate exclusion."""
from pathlib import Path
from itertools import combinations
import re,subprocess,tempfile,shutil,sys
from cofactors import core,orbit,automorphisms
q=Path(__file__).resolve().parent
autos=automorphisms()
assert len(autos)==120
def upper(mask):
    V,E=core(mask)
    if not E: return 0
    cover=next(k for k in range(len(V)+1) if any(all(a in C or b in C for a,b in E) for C in combinations(V,k)))
    return len(E)+cover-1

with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp)
    def build(src):
        out=tmp/src
        subprocess.run(['c++','-std=c++20','-O3',q/(src+'.cpp'),'-o',out],check=True)
        return out
    base=build('subgraph'); certified=build('bounded')
    def run(*args):
        r=subprocess.run(list(map(str,args)),text=True,capture_output=True,check=True)
        print(r.stdout.splitlines()[0],flush=True)
        return int(re.search(r'found ([01])',r.stdout)[1])
    assert run(base,1,3)==1 and run(base,1,7)==0 and run(base,2,7)==1
    bounds={}
    def record(mask,lb):
        for v in orbit(mask,autos):
            bounds[v]=max(bounds.get(v,0),lb)
    def cutfile(mask):
        c=tmp/f'cut-{mask}.txt'
        verts=[v for v in range(10) if mask>>v&1]
        with c.open('w') as f:
            for k in (1,2):
                for vertices in combinations(verts,k):
                    cut=sum(1<<x for x in vertices)
                    b=bounds[mask^cut]
                    if b>0:f.write(f'{cut} {b}\n')
        return c
    for n in (5,6,7):
        todo={sum(1<<i for i in S) for S in combinations(range(10),n)}
        while todo:
            m=min(todo);todo-=orbit(m,autos)
            # A two-input gate can combine at most two live wires, hence at
            # least r-1 gates are needed to connect r essential inputs.
            lb=max(0,len(core(m)[0])-1)
            for k in range(upper(m)-1,lb-1,-1):
                if not run(base,k,m):
                    lb=k+1;break
            record(m,lb)
    for mask,budget in ((1020,12),(1018,11),(1022,14)):
        cuts=cutfile(mask)
        assert not run(certified,budget,mask,cuts,'free')
        record(mask,budget+1)
    if '--exact-nine' in sys.argv[1:]:
        from replay_nine import validate_witness
        validate_witness()
        assert not run(certified,15,1022,cutfile(1022),'free')
        print('Exact binary gate complexity after one vertex deletion: 16.',flush=True)
    full=1023;cuts=cutfile(full)
    assert {tuple(sorted((g[0],g[j]))) for g in autos for j in (1,2)}==set(combinations(range(10),2))
    for j in (1,2):
        for sign in range(4):assert not run(certified,17,full,cuts,'free',0,j,sign)
    print('No circuit with at most seventeen binary gates and free negations.',flush=True)
