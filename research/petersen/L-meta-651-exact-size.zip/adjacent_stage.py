"""Run from the temporary replay directory after all smaller profiles have been regenerated."""
from pathlib import Path
import re,subprocess
from cofactors import automorphisms
from conditioned import bound,image
from root_profiles import translate
q=Path(__file__).resolve().parent
def no(*args):
 r=subprocess.check_output(list(map(str,args)),text=True)
 print(r.splitlines()[0],flush=True)
 assert re.search(r'found 0\b',r)
autos=automorphisms(); group=[g for g in autos if image(1022,g)==1022]
root=(1,2,3)
no(q/'anchoredfree',16,1022,q/'anchor-nine-1-2-3.txt','free',*root)
forbidden={translate(root,g) for g in group}
for j,s in [(j,s) for j in (1,2) for s in (0,1,2)]+[(1,3)]:
 r=(0,j,s);path=q/'final-cuts.txt'
 with path.open('w') as out:
    for cut in range(1,1024):
        if cut.bit_count()==1:
            p=next(g for g in autos if image(1023^cut,g)==1022)
            lower=16+int(not(cut&(1|(1<<j))) and translate(r,p) in forbidden)
        elif cut.bit_count()==2:
            adjacent=any(image(cut,g)==3 for g in autos)
            lower=bound(1023,cut,13 if adjacent else 12,r)
        else:continue
        print(cut,lower,file=out)
 no(q/'bounded',18,1023,path,'free',*r)
print('Every surviving 18-binary-gate circuit has only ORs on nonadjacent pairs among its raw-input gates.',flush=True)
