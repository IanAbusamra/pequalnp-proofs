"""Run from the temporary replay directory with small-graph spectra already verified."""
from itertools import combinations
from pathlib import Path
import json,subprocess,sys
from cofactors import automorphisms
from conditioned import image
from mono_anchors import make
from matchings import orbits
q=Path(__file__).resolve().parent;auto=automorphisms()
base=[]
for cut in range(1,1024):
 if cut.bit_count()==1:base.append((cut,16))
 if cut.bit_count()==2:base.append((cut,13 if any(image(cut,p)==3 for p in auto) else 12))
(q/'mono-cuts-1023.txt').write_text(''.join(f'{a} {b}\n' for a,b in base))
def stage(name,*args):
 subprocess.run([sys.executable,q/(name+'.py'),*map(str,args)],check=True)
def require_negative(f):
 line=f.read_text().splitlines()[0];assert 'found 0 ' in line,line
stage('matchings',5,4,3,2,1)
for t in range(1,6):
 for m,_ in orbits(t):
    require_negative(q/f'partial-{sum(1<<i for i in m)}.log')
stage('mono_anchors')
profile=json.loads((q/'mono-root-profile.json').read_text());assert len(profile)==36
r=(0,1,3);c=make(1023,r,base,'mono-full-1.txt',profile)
with (q/'adjacent-mono.log').open('w') as f:
 subprocess.run([q/'anchored','19','1023',c,'0','1',*map(str,r)],stdout=f,check=True)
require_negative(q/'adjacent-mono.log')
stage('pair_profiles');stage('pair_full')
edges={(0,1),(1,2),(2,3),(3,4),(0,4),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(6,9),(6,8),(5,8)}
pairs={b for b in combinations(range(10),2) if b not in edges}
todo=set(combinations(sorted(pairs),2))
require_negative(q/'pairfull-solo.log')
while todo:
 rs=min(todo)
 orbit={tuple(sorted(tuple(sorted((p[a],p[b]))) for a,b in rs)) for p in auto}
 todo-=orbit
 rep=min(next(x for x in t if x!=(0,2)) for t in orbit if (0,2) in t)
 require_negative(q/f'pairfull-{rep[0]}-{rep[1]}.log')
print('Excluded monotone Petersen circuits of size at most 19.',flush=True)
