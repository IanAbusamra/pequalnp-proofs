// Explore live circuits, using lower bounds for specified zero restrictions.
// Usage: cuts BUDGET VERTICES CUTS_FILE MODE [FIRST_A FIRST_B POLARITY]
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

using Word=uint64_t;
using Table=std::array<Word,16>;
using State=std::vector<int>;
using Bits=std::array<Word,10>;
struct Sample { Bits pos{},neg{},sep{}; };
struct Capacity {
  std::array<Word,5> planes{};
  bool operator==(const Capacity&) const=default;
  bool take(Word cuts) {
    for(auto& plane:planes) {
      if(!cuts) return true;
      Word borrow=cuts&~plane;
      plane^=cuts;
      cuts=borrow;
    }
    return cuts==0;
  }
};
struct Wire {Table table; Sample sample; Word constant,raw_alias;};
struct TableHash {
  size_t operator()(const Table& t) const {
    Word h=1;
    for(auto x:t) h=(h^x)*1099511628211ull;
    return h;
  }
};
struct Entry { State state; Capacity capacity; int depth=-1,last=-1; unsigned current=0,previous=0; };
struct Step {int left,right,inv,out;};
std::vector<Entry> memo(1<<17);
std::vector<Wire> wires;
std::unordered_map<Table,int,TableHash> ids;
std::vector<unsigned> references;
std::vector<int> free_ids;
void retain(int id) {++references[id];}
void release(int id) {
  if(--references[id]==0) {
    ids.erase(wires[id].table);
    free_ids.push_back(id);
  }
}
struct Pin {
  int id;
  explicit Pin(int value):id(value){retain(id);}
  ~Pin(){release(id);}
  Pin(const Pin&)=delete;
};
std::vector<std::pair<int,int>> pairs;
std::array<std::vector<std::pair<int,int>>,1024> conflicts;
std::vector<Step> path;
std::array<std::pair<int,int>,15> edges={{{0,1},{1,2},{2,3},{3,4},{4,0},{0,5},{1,6},{2,7},{3,8},{4,9},{5,7},{7,9},{9,6},{6,8},{8,5}}};
std::array<std::array<Word,256>,128> agreement_byte;
Word all_cuts=0;
Bits valid_pairs{};
int vertices,binary_budget,target,first_a=-1,first_b=-1,first_sign=-1;
bool monotone=false;
unsigned long long explored=0;

Capacity initialize_cuts(const char* filename) {
  std::ifstream input(filename);
  if(!input) throw std::runtime_error("cannot open restriction bounds");
  Capacity capacity;
  std::array<Word,1024> hits{};
  unsigned count=0;
  int cut,lower;
  while(input>>cut>>lower) {
    if(count>=63 || cut<=0 || (cut&~vertices) || lower<0 || lower>binary_budget)
      throw std::runtime_error("invalid cut or infeasible input budget");
    Word id=1ull<<count++;
    all_cuts|=id;
    for(int x=0;x<1024;++x) if(x&cut) hits[x]|=id;
    for(unsigned bit=0;bit<capacity.planes.size();++bit)
      if(((binary_budget-lower)>>bit)&1) capacity.planes[bit]|=id;
  }
  for(int byte=0;byte<128;++byte) {
    auto& row=agreement_byte[byte];
    row[0]=all_cuts;
    for(unsigned d=1;d<256;++d)
      row[d]=row[d&(d-1)] & hits[8*byte+std::countr_zero(d)];
  }
  return capacity;
}
Word agrees(const Table& a,const Table& b) {
  Word result=all_cuts;
  for(int j=0;j<16 && result;++j) {
    Word diff=a[j]^b[j];
    for(int byte=j*8;diff && result;++byte,diff>>=8)
      result &= agreement_byte[byte][diff&255];
  }
  return result;
}
int add_wire(const Table& t,Word cm,Word alias) {
  int id=wires.size();
  Wire w{t,{},cm,alias};
  for(size_t i=0;i<pairs.size();++i) {
    auto [p,n]=pairs[i];
    w.sample.pos[i/64]|=((t[p/64]>>(p%64))&1ull)<<(i%64);
    w.sample.neg[i/64]|=((t[n/64]>>(n%64))&1ull)<<(i%64);
  }
  for(int i=0;i<10;++i) w.sample.sep[i]=monotone ? w.sample.pos[i]&~w.sample.neg[i] : w.sample.pos[i]^w.sample.neg[i];
  if(free_ids.empty()) {
    wires.push_back(w);
    references.push_back(0);
  } else {
    id=free_ids.back(); free_ids.pop_back();
    wires[id]=w;
  }
  ids.emplace(t,id);
  return id;
}
bool separates(const State& s) {
  int raw=0;
  State derived;
  for(int w:s) {
    if(w<10) raw|=1<<w;
    else derived.push_back(w);
  }
  // Equality of all coordinates precludes either model from separating a pair.
  for(auto [p,n]:conflicts[raw]) {
    bool distinguished=false;
    for(int w:derived) {
      const Table& t=wires[w].table;
      if(((t[p/64]>>(p%64))^(t[n/64]>>(n%64)))&1) {distinguished=true;break;}
    }
    if(!distinguished) return false;
  }
  return true;
}
bool remembered(const State& s,int depth,const Capacity& cap,unsigned current,unsigned previous,int last) {
  Word h=(Word(current)<<28) ^ (Word(previous)<<7) ^ Word(last+2) ^ Word(depth+1);
  for(int w:s) h=(h^(w+1))*1099511628211ull;
  for(auto v:cap.planes) h=(h^v)*1099511628211ull;
  h^=h>>32;
  auto& slot=memo[h&(memo.size()-1)];
  if(slot.depth==depth && slot.last==last && slot.current==current && slot.previous==previous && slot.capacity==cap && slot.state==s) return true;
  for(int w:s) retain(w);
  for(int w:slot.state) release(w);
  slot={s,cap,depth,last,current,previous};
  return false;
}
bool solve(const State& s,int budget,const Capacity& cap,unsigned current,unsigned previous,int last) {
  if(std::binary_search(s.begin(),s.end(),target)) return true;
  if(!budget || int(s.size())>budget+1 || remembered(s,budget,cap,current,previous,last) || !separates(s)) return false;
  ++explored;
  for(size_t i=0;i<s.size();++i) for(size_t j=i+1;j<s.size();++j) {
    unsigned operands=(1u<<i)|(1u<<j);
    bool same_layer=!(operands&current);
    if(same_layer && !(operands&previous)) continue;
    int a=s[i],b=s[j];
    if(budget==binary_budget && first_a>=0 && (a!=first_a || b!=first_b)) continue;
    State rest;
    Bits need=valid_pairs;
    Capacity reserved=cap;
    for(int w:s) if(w!=a && w!=b) {
      rest.push_back(w);
      if(!reserved.take(wires[w].constant)) throw std::runtime_error("live reserve invariant");
      for(int z=0;z<10;++z) need[z]&=~wires[w].sample.sep[z];
    }
    for(int inv=0;inv<4;++inv) {
      if(monotone && inv!=0 && inv!=3) continue;
      if(budget==binary_budget && first_a>=0 && inv!=first_sign) continue;
      bool possible[4]={true,true,true,true};
      for(int z=0;z<10;++z) {
        const auto &x=wires[a].sample,&y=wires[b].sample;
        Word p=(inv&1?~x.pos[z]:x.pos[z])&(inv&2?~y.pos[z]:y.pos[z]);
        Word n=(inv&1?~x.neg[z]:x.neg[z])&(inv&2?~y.neg[z]:y.neg[z]);
        // Both complemented inputs yield an output that is complemented on normalization.
        if(inv==3) {p=~p;n=~n;}
        Word miss=need[z]&~(monotone?p&~n:p^n);
        if(miss) possible[0]=false;
        if(miss&~x.sep[z]) possible[1]=false;
        if(miss&~y.sep[z]) possible[2]=false;
      }
      bool any=false;
      for(unsigned k=0;k<4;++k) {
        if(int(rest.size())+1+std::popcount(k)>budget) possible[k]=false;
        any|=possible[k];
      }
      if(!any) continue;
      Table t;
      for(int z=0;z<16;++z) {
        Word x=wires[a].table[z],y=wires[b].table[z];
        t[z]=(inv&1?~x:x)&(inv&2?~y:y);
        if(inv==3) t[z]=~t[z];
      }
      if(same_layer && last>=0 && !(wires[last].table < t)) continue;
      auto it=ids.find(t);
      int c=it==ids.end()?-1:it->second;
      if(c==10 || (c>=0 && std::binary_search(s.begin(),s.end(),c))) continue;
      Word cm=c<0?agrees(t,Table{}):wires[c].constant;
      Word alias=c<0?cm:wires[c].raw_alias;
      if(c<0) for(int w=0;w<10;++w) if(vertices&(1<<w)) alias|=agrees(t,wires[w].table);
      Word saved=alias;
      for(int w:s) if(w>=10) saved|=agrees(t,wires[w].table);
      Capacity next_cap=cap,check=reserved;
      if(!next_cap.take(saved) || !check.take(saved) || !check.take(cm)) continue;
      if(c<0) c=add_wire(t,cm,alias);
      Pin candidate(c);
      for(unsigned keep=0;keep<4;++keep) if(possible[keep]) {
        Capacity test=check;
        if((keep&1) && !test.take(wires[a].constant)) continue;
        if((keep&2) && !test.take(wires[b].constant)) continue;
        State next=rest;
        if(keep&1) next.push_back(a);
        if(keep&2) next.push_back(b);
        next.push_back(c);
        std::sort(next.begin(),next.end());
        path.push_back({a,b,inv,c});
        unsigned nc=0,np=0;
        for(size_t k=0;k<next.size();++k) {
          if(next[k]==c) {nc|=1u<<k;continue;}
          unsigned z=std::lower_bound(s.begin(),s.end(),next[k])-s.begin();
          if(same_layer && (current&(1u<<z))) nc|=1u<<k;
          if((same_layer?previous:current)&(1u<<z)) np|=1u<<k;
        }
        // A requested first gate may precede the sorted remainder of its layer.
        int last_new=(budget==binary_budget && first_a>=0)?-1:c;
        if(solve(next,budget-1,next_cap,nc,np,last_new)) return true;
        path.pop_back();
      }
    }
  }
  return false;
}
int main(int argc,char** argv) {
  if(argc!=5 && argc!=8) return 2;
  binary_budget=std::stoi(argv[1]); vertices=std::stoi(argv[2]);
  if(binary_budget<1 || binary_budget>25 || vertices<1 || vertices>1023) return 2;
  std::string mode=argv[4];
  if(mode!="monotone" && mode!="free") return 2;
  monotone=mode=="monotone";
  if(argc==8) {
    first_a=std::stoi(argv[5]);first_b=std::stoi(argv[6]);first_sign=std::stoi(argv[7]);
    if(first_a<0 || first_a>=first_b || first_b>9 || first_sign<0 || first_sign>3) return 2;
  }
  auto start=std::chrono::steady_clock::now();
  auto capacity=initialize_cuts(argv[3]);
  std::array<Table,10> raw{};
  Table goal{};
  std::vector<int> pos,neg;
  int active=0;
  for(int x=0;x<1024;++x) {
    bool value=false;
    for(int i=0;i<10;++i) if(x&(1<<i)) raw[i][x/64]|=1ull<<(x%64);
    for(auto [a,b]:edges) if((vertices>>a)&(vertices>>b)&1) {
      active|=(1<<a)|(1<<b);
      value|=(x>>a)&(x>>b)&1;
    }
    if(value) goal[x/64]|=1ull<<(x%64);
    if(!(x&~vertices)) (value?pos:neg).push_back(x);
  }
  auto add=[](int p,int n) {
    if(std::find(pairs.begin(),pairs.end(),std::pair{p,n})==pairs.end()) pairs.emplace_back(p,n);
  };
  for(int n:neg) {
    bool maximal=true;
    for(int j=0;j<10;++j) if(vertices&(1<<j) && !(n&(1<<j)) && std::binary_search(neg.begin(),neg.end(),n|(1<<j))) maximal=false;
    if(maximal) for(auto [a,b]:edges) if((vertices>>a)&(vertices>>b)&1) add((1<<a)|(1<<b),n);
    for(int j=0;j<10;++j) if(std::binary_search(pos.begin(),pos.end(),n|(1<<j))) add(n|(1<<j),n);
  }
  if(pairs.empty() || pairs.size()>640) return 4;
  for(size_t i=0;i<pairs.size();++i) valid_pairs[i/64]|=1ull<<(i%64);
  State first;
  for(int j=0;j<10;++j) {
    retain(add_wire(raw[j],agrees(raw[j],Table{}),all_cuts));
    if(active&(1<<j)) first.push_back(j);
  }
  retain(add_wire(Table{},all_cuts,all_cuts));
  Word goal_cm=agrees(goal,Table{}),goal_alias=goal_cm;
  for(int j=0;j<10;++j) if(active&(1<<j)) goal_alias|=agrees(goal,raw[j]);
  target=add_wire(goal,goal_cm,goal_alias); retain(target);
  for(int m=0;m<1024;++m) for(int n:neg) for(int p:pos) if(!((p^n)&m)) conflicts[m].emplace_back(p,n);
  Capacity initial_check=capacity;
  bool can_start=true;
  for(int w:first) if(!initial_check.take(wires[w].constant)) can_start=false;
  bool found=can_start && solve(first,binary_budget,capacity,(1u<<first.size())-1,0,-1);
  std::cout<<"budget "<<binary_budget<<" vertices "<<vertices<<" mode "<<mode<<" first "<<first_a<<" "<<first_b<<" "<<first_sign
    <<" found "<<found<<" states "<<explored<<" wires "<<wires.size()<<" seconds "
    <<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"\n";
  if(found) {
    std::unordered_map<int,int> index;
    for(int j=0;j<10;++j) index[j]=j;
    int next=10;
    for(auto step:path) {
      std::cout<<next<<" "<<index.at(step.left)<<" "<<index.at(step.right)<<" "<<step.inv<<"\n";
      index[step.out]=next++;
    }
  }
}
