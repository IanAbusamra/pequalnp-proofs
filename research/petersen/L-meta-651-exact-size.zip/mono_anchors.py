from conditioned import bound,image
from root_profiles import translate
from cofactors import automorphisms,E
from itertools import combinations
from pathlib import Path
import subprocess,re,json
q=Path(__file__).resolve().parent
def unchanged(mask,cut,root):
    a,b,s=root
    if cut&((1<<a)|(1<<b)):return False
    remaining=mask^cut
    ed=[(1<<i)|(1<<j) for i,j in E if (remaining>>i)&(remaining>>j)&1]
    if not ed:return False
    pos=ed; neg=[x for x in range(1024) if not (x&~remaining) and not any(x&e==e for e in ed)]
    nset=set(neg)
    maximal=[x for x in neg if all((x|1<<v) not in nset for v in range(10) if remaining&(1<<v) and not x&(1<<v))]
    def gate(x):
        return bool((x&(1<<a)) or (x&(1<<b))) if s==3 else bool((x&(1<<a)) and (x&(1<<b)))
    for y in [lambda x:False,lambda x:True,*[lambda x,v=v:bool(x&(1<<v)) for v in range(10)]]:
        if all(not gate(x) or y(x) for x in pos) and all(not y(x) or gate(x) for x in maximal):
            return False
    return True
def make(mask,root,base,label,profile_nine=None):
    cuts=q/label
    with cuts.open('w') as f:
        for cut,lb in base:
            val=lb
            if unchanged(mask,cut,root):
                if mask==1023 and cut.bit_count()==1:
                    if profile_nine is not None:
                        p=next(p for p in automorphisms() if image(mask^cut,p)==1022)
                        r=translate(root,p)
                        val=profile_nine.get(','.join(map(str,r)),lb)
                else:val=bound(mask,cut,lb,root)
            f.write(f'{cut} {val}\n')
    return cuts
def main():
    mask=1022; base=[tuple(map(int,l.split())) for l in (q/'cuts-1022.txt').read_text().splitlines()]
    group=[p for p in automorphisms() if image(mask,p)==mask]
    roots={(*e,3) for e in combinations(range(1,10),2)};results={}
    while roots:
        root=min(roots);o={translate(root,p) for p in group};roots-=o
        key='-'.join(map(str,root));cuts=make(mask,root,base,f'mono-nine-{key}.txt')
        out=q/f'mono-nine-{key}.log'
        with out.open('w') as f:subprocess.run([q/'boundary','16',str(mask),cuts,'monotone',*map(str,root)],stdout=f,check=True)
        text=out.read_text();flag=int(re.search(r'found ([01])',text)[1])
        print(text.splitlines()[0],flush=True)
        for r in o:results[','.join(map(str,r))]=17-flag
        (q/'mono-root-profile.json').write_text(json.dumps(results,sort_keys=True))
if __name__=='__main__':main()
