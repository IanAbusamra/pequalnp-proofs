"""Charge each cofactor once when a retained gate on raw inputs excludes all minima."""
from pathlib import Path
from itertools import combinations
from functools import cache
import json
from conditioned import bound,image
from root_profiles import translate
from cofactors import automorphisms,core
q=Path(__file__).resolve().parent

def sources(src,dest):
 s=(q/src).read_text()
 s=s.replace('struct Capacity {','Word exclusions[10][10][4]{};\nstruct Capacity {\n  Word charged{};')
 s=s.replace('Word h=(Word(current)', 'Word h=cap.charged ^ (Word(current)')
 x='      Capacity next_cap=cap,check=reserved;'
 patch="""      // Retain this raw gate in the restricted circuit, even if it becomes dead.
      // It can be scheduled first because both operands are original inputs.
      Word extra=(a<10 && b<10)?exclusions[a][b][inv]&~saved&~cap.charged:0;
      Capacity next_cap=cap,check=reserved;
      next_cap.charged|=extra;
      if(!next_cap.take(extra) || !check.take(extra)) continue;"""
 assert s.count(x)==1;s=s.replace(x,patch)
 x='  auto capacity=initialize_cuts(argv[3]);'
 s=s.replace(x,x+"""
  std::ifstream roots(std::string(argv[3])+".roots");
  if(!roots) throw std::runtime_error("missing root profiles");
  int a,b,sign; Word mask;
  while(roots>>a>>b>>sign>>mask) {
    if(a<0 || a>=b || b>=10 || sign<0 || sign>=4 || (mask&~all_cuts))
      throw std::runtime_error("invalid root profile");
    exclusions[a][b][sign]=mask;
  }""")
 (q/dest).write_text(s)
@cache
def nine_perm(mask):return next(p for p in automorphisms() if image(mask,p)==1022)

def files(mask,mode,extra_nine=None):
 basefile='mono-cuts-1023.txt' if mask==1023 else 'cuts-1022.txt'
 base=[tuple(map(int,l.split())) for l in (q/basefile).read_text().splitlines()]
 prof=(json.loads((q/'mono-root-profile.json').read_text()) if mode=='mono' else {}) if extra_nine is None else extra_nine
 path=q/f'dynamic-{mask}-{mode}.txt'
 path.write_text(''.join(f'{c} {b}\n' for c,b in base))
 with Path(str(path)+'.roots').open('w') as f:
  for a,b in combinations(core(mask)[0],2):
   for sign in ([3] if mode=='mono' and mask==1023 else range(4)):
    r=(a,b,sign);bits=0
    for i,(cut,lb) in enumerate(base):
     if cut&(1<<a|1<<b):continue
     if mask==1023 and cut.bit_count()==1:
      name=','.join(map(str,translate(r,nine_perm(mask^cut))))
      new=prof.get(name,lb)
     else:new=bound(mask,cut,lb,r)
     assert new in (lb,lb+1)
     if new>lb:bits|=1<<i
    if bits:print(a,b,sign,bits,file=f)
 return path
if __name__=='__main__':
 sources('bounded.cpp','dynamicfree.cpp');sources('partial.cpp','dynamicmono.cpp')
 for mask,mode in [(1023,'mono'),(1023,'free'),(1022,'free')]:files(mask,mode)
