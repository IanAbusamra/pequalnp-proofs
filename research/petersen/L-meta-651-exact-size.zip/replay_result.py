"""Replay the computational lower bound for project assignment L-meta-651."""
from pathlib import Path
import subprocess,sys
q=Path(__file__).resolve().parent
subprocess.run([sys.executable,q/'replay18.py'],check=True)
options=['--adjacent','--final']
if '--signed-only' not in sys.argv[1:]:options.append('--monotone')
subprocess.run([sys.executable,q/'replay_nine.py',*options],check=True)
if '--signed-only' not in sys.argv[1:]:
 print('All lower-bound cases passed. The ordinary Petersen edge function requires at least 20 gates.',flush=True)
