"""Exact free-NOT binary search for induced subgraphs and restriction lower bounds."""
from functools import lru_cache
from itertools import combinations,product
from time import monotonic
import sys
from free_neg import E

@lru_cache(maxsize=None)
def core(vertices):
    edges=[(i,j) for i,j in E if (vertices>>i)&(vertices>>j)&1]
    return tuple(sorted({v for e in edges for v in e})),edges

def exact(vertices,budget):
    vs,edges=core(vertices)
    n=len(vs)
    if not edges:return budget>=0,0
    edges=[(vs.index(i),vs.index(j)) for i,j in edges]
    positives=[(1<<a)|(1<<b) for a,b in edges]
    def f(x):return any((x&w)==w for w in positives)
    neg=[x for x in range(1<<n) if not f(x)]
    maximal=[x for x in neg if all(f(x|1<<i) for i in range(n) if not (x>>i)&1)]
    pairs=list(dict.fromkeys([*product(positives,maximal),*((x|1<<j,x) for x in neg for j in range(n) if f(x|1<<j))]))
    width=len(pairs);mask=(1<<width)-1;full=(1<<(2*width))-1
    def canon(x):return min(x,x^full)
    raw=tuple(canon(sum((((p>>i&1)<<width)|(z>>i&1))<<j for j,(p,z) in enumerate(pairs))) for i in range(n))
    target=canon(mask<<width)
    @lru_cache(maxsize=60000)
    def sep(x):return ((x>>width)^x)&mask
    @lru_cache(maxsize=100000)
    def hit(v,b):
        if target in v:return True
        if len(v)>b+1 or b==0:return False
        for i,j in combinations(range(len(v)),2):
            a,h=v[i],v[j]
            rest=v[:i]+v[i+1:j]+v[j+1:]
            other=0
            for z in rest:other|=sep(z)
            for out in set(canon(x&y) for x in (a,full^a) for y in (h,full^h)):
                if out==0 or out in v:continue
                covered=other|sep(out)
                for keep in ((),(a,),(h,),(a,h)):
                    if len(rest)+len(keep)+1>b:continue
                    cov=covered
                    for z in keep:cov|=sep(z)
                    if cov==mask and hit(tuple(sorted((*rest,*keep,out))),b-1): return True
        return False
    result=hit(tuple(sorted(raw)),budget);states=hit.cache_info().misses
    hit.cache_clear();sep.cache_clear()
    return result,states

def automorphisms():
    adj={tuple(sorted(e)) for e in E}
    def visit(p):
        if len(p)==10:yield tuple(p);return
        i=len(p)
        for j in range(10):
            if j not in p and all(((k,i) in adj)==(tuple(sorted((p[k],j))) in adj) for k in range(i)):
                yield from visit([*p,j])
    return list(visit([]))

def orbit(rep,autos):
    return {sum(((rep>>i)&1)<<a[i] for i in range(10)) for a in autos}

def robust(v,w,edges):
    N=lambda u:{b if a==u else a for a,b in edges if u in (a,b)}
    return bool(N(v)-{w}) and (w in N(v) or bool(N(v)-N(w)-{w}))

@lru_cache(maxsize=None)
def elimination(V):
    vs,edges=core(V)
    if len(vs)<2:return 0
    support=sum(1<<v for v in vs)
    if V!=support:return elimination(support)
    if V in seeds:return seeds[V]
    options=[]
    for a,b in combinations(vs,2):
        options.append(max(elimination(V^(1<<v))+1+int(robust(v,w,edges)) for v,w in ((a,b),(b,a))))
    return max(len(vs)-1,min(options))

def pairs_check():
    autos=automorphisms()
    assert len(autos)==120
    p0,p1=1023^1^2,1023^1^4
    assert orbit(p0,autos)|orbit(p1,autos)=={1023^(1<<a)^(1<<b) for a,b in combinations(range(10),2)}
    return p0,p1

seeds={}
if __name__=='__main__':
    p0,p1=pairs_check()
    print("Without enumeration:",elimination(1023),flush=True)
    for v in (p0,p1):
        for budget in [10,11,12]:
            start=monotonic();ok,states=exact(v,budget)
            print(v,budget,ok,states,round(monotonic()-start,3),flush=True)
            if ok:break
            for s in orbit(v,automorphisms()):seeds[s]=budget+1
    elimination.cache_clear()
    print("With two-deletion searches:",elimination(1023),flush=True)
