"""Attach exact first-gate bounds to the eight-vertex cofactor searches."""
from itertools import combinations,permutations
from pathlib import Path
import json,re,subprocess
from cofactors import core
q=Path(__file__).resolve().parent
def group(mask):
    vs,edges=core(mask); E={tuple(sorted(e)) for e in edges}
    for p in permutations(vs):
        a=dict(zip(vs,p))
        if all(tuple(sorted((a[i],a[j]))) in E for i,j in E):yield a
def translate(g,p):
    i,j,s=g;i,j=p[i],p[j]
    if i>j:return j,i,((s&1)<<1)|((s&2)>>1)
    return i,j,s
def main():
    for v,budget in [(1020,13),(1018,12)]:
        vs,_=core(v); group_elements=list(group(v))
        gaps={(*e,s) for e in combinations(vs,2) for s in range(4)};profile={}
        while gaps:
            root=min(gaps); orb={translate(root,p) for p in group_elements};gaps-=orb
            r=subprocess.run([q/'bounded',str(budget),str(v),q/f'cuts-{v}.txt','free',*map(str,root)],capture_output=True,text=True,check=True)
            flag=int(re.search(r'found ([01])',r.stdout)[1])
            if flag:
                # Validate every emitted signed circuit on all assignments of the original ten inputs.
                rows=[tuple(map(int,line.split())) for line in r.stdout.splitlines()[1:]]
                assert len(rows)<=budget
                for x in range(1024):
                    vals=[bool(x&(1<<i)) for i in range(10)]
                    for k,a,b,inv in rows:
                        assert k==len(vals)
                        val=(vals[a]^bool(inv&1)) and (vals[b]^bool(inv&2))
                        vals.append(val^(inv==3))
                    assert vals[-1]==any((x>>a)&(x>>b)&1 for a,b in core(v)[1])
            for elt in orb:profile[','.join(map(str,elt))]=budget+(not flag)
            print(v,root,len(orb),r.stdout.splitlines()[0],flush=True)
            (q/f'profile-{v}.json').write_text(json.dumps(profile,sort_keys=True))
if __name__=='__main__': main()
