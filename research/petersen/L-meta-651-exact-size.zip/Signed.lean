import Mathlib
import PEqualNP.Defs

namespace PetersenSigned
open PEqualNP.CircuitLowerBounds PEqualNP.MetaComplexity

abbrev Signal (α : Type) := α → Bool
def neg {α} (a : Signal α) : Signal α := fun x => !(a x)
def conj {α} (a b : Signal α) : Signal α := fun x => a x && b x

/-- Constants and both polarities of every stored signal are available. -/
inductive Available {α : Type} (s : List (Signal α)) : Signal α → Prop where
  | zero : Available s (fun _ => false)
  | one : Available s (fun _ => true)
  | pos {a} : a ∈ s → Available s a
  | negated {a} : a ∈ s → Available s (neg a)

private theorem flip {α} {s : List (Signal α)} {a} (h : Available s a) :
    Available s (neg a) := by
  cases h with
  | zero => exact .one
  | one => exact .zero
  | pos h => exact .negated h
  | negated h =>
    rename_i t
    have e : neg (neg t) = t := by funext x; simp [neg]
    rw [e]
    exact .pos h

private theorem extend {α} {s : List (Signal α)} {a} (h : Available s a) (g) :
    Available (g::s) a := by
  cases h with
  | zero => exact .zero
  | one => exact .one
  | pos h => exact .pos (List.mem_cons_of_mem _ h)
  | negated h => exact .negated (List.mem_cons_of_mem _ h)

/-- A binary AND adds a stored wire. Input and output polarity changes are free. -/
inductive Builds {α : Type} : Nat → List (Signal α) → Signal α → Prop where
  | stop {s f} : Available s f → Builds 0 s f
  | gate {k s f a b} : Available s a → Available s b →
      Builds k (conj a b :: s) f → Builds (k+1) s f

private def readWire {α} (w : List (Signal α)) (i : Nat) : Signal α := w.getD i (fun _ => false)
private def run {α} (w : List (Signal α)) : List Gate → List (Signal α)
  | [] => w
  | g :: gs => run (w ++ [fun x => g.op.eval (g.inputs.map fun i => readWire w i x)]) gs

private theorem read_ok {α} {w s : List (Signal α)} (hw : ∀ a ∈ w, Available s a) (i : Nat) :
    Available s (readWire w i) := by
  simp only [readWire,List.getD_eq_getElem?_getD]
  cases h : w[i]? with
  | none => exact .zero
  | some a => exact hw _ (List.mem_of_getElem? h)

private theorem factors {α} {s : List (Signal α)} (l : List (Signal α))
    (hl : l.length ≤ 2) (h : ∀ a ∈ l, Available s a) :
    ∃ a b, Available s a ∧ Available s b ∧
      (fun x => l.all (fun z => z x)) = conj a b := by
  cases l with
  | nil => exact ⟨_,_,.one,.one,rfl⟩
  | cons a as =>
    cases as with
    | nil =>
      exact ⟨a,_,h a (by simp),.one,by funext x; simp [conj]⟩
    | cons b bs =>
      cases bs with
      | nil => exact ⟨a,b,h a (by simp),h b (by simp),by funext x; simp [conj]⟩
      | cons c cs => simp at hl

def binaryOp : GateOp → Bool
  | .and | .or => true
  | _ => false

private theorem normalize {α : Type} (gs : List Gate) (out : Nat) (w s : List (Signal α))
    (hw : ∀ a ∈ w, Available s a) (ok : ∀ g ∈ gs,
     (g.op = .and ∨ g.op = .or ∨ g.op = .not) ∧ g.inputs.length ≤ 2) :
    Builds (gs.countP fun g => binaryOp g.op) s (readWire (run w gs) out) := by
  induction gs generalizing w s with
  | nil => exact .stop (read_ok hw out)
  | cons g gs ih =>
    let v : Signal α := fun x => g.op.eval (g.inputs.map fun i => readWire w i x)
    let reads := g.inputs.map (readWire w)
    have hr : ∀ z ∈ reads, Available s z := by
      intro z hz
      obtain ⟨i,_,rfl⟩ := List.mem_map.mp hz
      exact read_ok hw i
    obtain ⟨hops,hlen⟩ := ok g (by simp)
    have len : reads.length ≤ 2 := by simpa [reads] using hlen
    have tailok := fun k (hk : k ∈ gs) => ok k (by simp [hk])
    have next {s' : List (Signal α)} (hkeep : ∀ f ∈ w, Available s' f) (hv : Available s' v) :
        Builds (gs.countP fun g => binaryOp g.op) s' (readWire (run w (g::gs)) out) := by
      apply ih (w++[v]) s' _ tailok
      intro a ha
      rcases List.mem_append.mp ha with ha | ha
      · exact hkeep _ ha
      · simpa only [List.mem_singleton.mp ha] using hv
    rcases hops with ha | ho | hn
    · obtain ⟨a,b,aa,ab,e⟩ := factors reads len hr
      have he : v = conj a b := by
        rw [← e]
        funext x
        simp [v,reads,ha,GateOp.eval,List.all_map,Function.comp_def]
      simp only [List.countP_cons,ha,binaryOp]
      apply Builds.gate aa ab
      apply next (fun f hf => extend (hw f hf) _)
      rw [he]
      exact .pos (by simp)
    · obtain ⟨a,b,aa,ab,e⟩ := factors (reads.map neg) (by simpa using len) (by
        intro z hz; obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hz; exact flip (hr i hi))
      have he : v = neg (conj a b) := by
        rw [← e]
        funext x
        simp [v,reads,ho,GateOp.eval,List.any_map,List.all_map,Function.comp_def,neg]
        induction g.inputs with
        | nil => rfl
        | cons i is ih => simp [ih,Bool.not_and]
      simp only [List.countP_cons,ho,binaryOp]
      apply Builds.gate aa ab
      apply next (fun f hf => extend (hw f hf) _)
      rw [he]
      exact .negated (by simp)
    · simp only [List.countP_cons,hn,binaryOp]
      apply next hw
      cases ind : g.inputs with
      | nil => simpa only [v,hn,ind,List.map_nil,GateOp.eval,List.headD_nil,Bool.not_false] using (Available.one (s := s))
      | cons i is =>
        have e : v = neg (readWire w i) := by funext x; simp [v,hn,ind,GateOp.eval,neg]
        rw [e]; exact flip (read_ok hw i)

private lemma read_map {α} (w : List (Signal α)) (i : Nat) (x : α) :
    (w.map (fun f => f x)).getD i false = readWire w i x := by
  simp only [readWire,List.getD_eq_getElem?_getD,List.getElem?_map]
  cases w[i]? <;> rfl

private lemma run_eval {α} (w : List (Signal α)) (gs : List Gate) (x : α) :
    (run w gs).map (fun f => f x) =
      gs.foldl (fun (v : List Bool) g => v ++ [g.op.eval (g.inputs.map (fun i => v.getD i false))])
        (w.map (fun f => f x)) := by
  induction gs generalizing w with
  | nil => rfl
  | cons g gs ih =>
    simp only [run, ih, List.foldl_cons,List.map_append,List.map_singleton,read_map]

def raw (n : Nat) : List (Signal (Fin n → Bool)) := List.ofFn (fun i : Fin n => fun x => x i)


/-- A project circuit yields a signed binary plan. Its length is exactly the number
of AND and OR gates, including any degenerate ones the project permits. -/
theorem circuit_to_signed (n : Nat) (C : Circuit) (hc : FanInTwo C) :
    Builds (C.gates.countP fun g => binaryOp g.op) (raw n) (fun x => C.eval (List.ofFn x)) := by
  have h := normalize C.gates C.output (raw n) (raw n) (fun _ h => .pos h) (by
    intro g hg
    obtain ⟨ha,hb⟩ := hc g hg
    exact ⟨by simpa only [Set.mem_insert_iff,Set.mem_singleton_iff] using ha,hb⟩)
  suffices e : readWire (run (raw n) C.gates) C.output = (fun x => C.eval (List.ofFn x)) by
    rwa [← e]
  funext x
  rw [← read_map,run_eval]
  simp [raw,List.map_ofFn,Circuit.eval,Circuit.wires,Function.comp_def]

/-- Separate the two sufficiency obligations for a gate-count lower bound.
The first concerns circuits containing no NOT; the second counts only binary gates. -/
theorem lower_of_two_bounds {n s : Nat} (f : (Fin n → Bool) → Bool)
    (mono : ∀ C : Circuit, FanInTwo C → C.size ≤ s+1 →
      (∀ g ∈ C.gates, g.op ≠ .not) →
      ¬ ∀ x, C.eval (List.ofFn x) = f x)
    (signed : ∀ k ≤ s, ¬ Builds k (raw n) f) : ¬ HasCircuitSize n f (s+1) := by
  rintro ⟨C,hc,hs,he⟩
  by_cases hm : ∀ g ∈ C.gates, g.op ≠ .not
  · exact mono C hc hs hm he
  · push Not at hm
    obtain ⟨g,hg,hn⟩ := hm
    have lt : C.gates.countP (fun z => binaryOp z.op) < C.gates.length := by
      apply Nat.lt_of_le_of_ne (List.countP_le_length ..)
      intro eqn
      have b := List.countP_eq_length.mp eqn g hg
      simp [hn,binaryOp] at b
    change C.gates.length ≤ s+1 at hs
    have hb := circuit_to_signed n C hc
    rw [show (fun x => C.eval (List.ofFn x)) = f from funext he] at hb
    exact signed _ (by omega) hb

/-- An explicit signed straight-line plan keeps the operands of every binary step. -/
def Trace {α} (s : List (Signal α)) : List (Signal α × Signal α) → Signal α → Prop
  | [], f => Available s f
  | (a,b)::gs, f => Available s a ∧ Available s b ∧ Trace (conj a b :: s) gs f

theorem trace_of_builds {α} {k s} {f : Signal α} (h : Builds k s f) :
    ∃ gs, gs.length = k ∧ Trace s gs f := by
  induction h with
  | stop h => exact ⟨[],rfl,h⟩
  | @gate k s f a b ha hb h ih =>
    obtain ⟨gs,hl,ht⟩ := ih
    exact ⟨(a,b)::gs,by simp [hl],ha,hb,ht⟩

private theorem transport {α β} (σ : β → α) {s : List (Signal α)} {t : List (Signal β)}
    (rel : ∀ z ∈ s, Available t (z ∘ σ)) {a} (h : Available s a) : Available t (a ∘ σ) := by
  cases h with
  | zero => exact .zero
  | one => exact .one
  | pos hz => exact rel _ hz
  | negated hz => exact flip (rel _ hz)

/-- Count projected gates that are already available as a constant or an earlier literal.
Earlier projected gates remain available even when their own computation was eliminated. -/
noncomputable def saved {α β} (σ : β → α) (s : List (Signal α)) :
    List (Signal α × Signal α) → Nat
  | [] => 0
  | (a,b)::gs => by
    classical
    let v := conj a b
    exact (if Available (s.map (fun z => z ∘ σ)) (v ∘ σ) then 1 else 0) + saved σ (v::s) gs

theorem restrict_trace {α β} (σ : β → α) (s : List (Signal α)) (gs : List (Signal α × Signal α))
    (f : Signal α) (h : Trace s gs f) (t : List (Signal β))
    (rel : ∀ z ∈ s, Available t (z ∘ σ)) :
    ∃ k, k + saved σ s gs = gs.length ∧ Builds k t (f ∘ σ) := by
  classical
  induction gs generalizing s t with
  | nil => exact ⟨0,rfl,.stop (transport σ rel h)⟩
  | cons g gs ih =>
    obtain ⟨a,b⟩ := g
    obtain ⟨ha,hb,hh⟩ := h
    let v := conj a b
    by_cases already : Available (s.map (fun z => z ∘ σ)) (v ∘ σ)
    · have hv : Available t (v ∘ σ) := by
        have hmap : ∀ z ∈ s.map (fun z => z ∘ σ), Available t z := by
          intro z hz
          obtain ⟨w,hw,rfl⟩ := List.mem_map.mp hz
          exact rel _ hw
        exact transport id (fun z hz => hmap z hz) already
      have rel' : ∀ z ∈ v::s, Available t (z ∘ σ) := by
        intro z hz
        rcases List.mem_cons.mp hz with rfl | hz
        · exact hv
        · exact rel _ hz
      obtain ⟨k,hk,hb⟩ := ih (s := v::s) hh t rel'
      refine ⟨k,?_,hb⟩
      change k + ((if Available (s.map (fun z => z ∘ σ)) (v ∘ σ) then 1 else 0) +
        saved σ (v::s) gs) = gs.length + 1
      simp only [already,ite_true]
      omega
    · let new := conj (a ∘ σ) (b ∘ σ)
      have rel' : ∀ z ∈ v::s, Available (new::t) (z ∘ σ) := by
        intro z hz
        rcases List.mem_cons.mp hz with rfl | hz
        · exact Available.pos (List.mem_cons_self)
        · exact extend (rel _ hz) new
      obtain ⟨k,hk,ht⟩ := ih (s := v::s) hh (new::t) rel'
      refine ⟨k+1,?_,.gate (transport σ rel ha) (transport σ rel hb) ht⟩
      change k + 1 + ((if Available (s.map (fun z => z ∘ σ)) (v ∘ σ) then 1 else 0) +
        saved σ (v::s) gs) = gs.length + 1
      simp only [already,ite_false,zero_add]
      omega

end PetersenSigned
#print axioms PetersenSigned.circuit_to_signed
#print axioms PetersenSigned.lower_of_two_bounds

#print axioms PetersenSigned.restrict_trace
