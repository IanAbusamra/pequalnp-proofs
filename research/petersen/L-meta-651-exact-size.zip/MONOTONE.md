# Monotone circuit size of the Petersen edge function

The target is true precisely when the selected vertices contain one of the 15 Petersen edges. The input numbering is the one used in L-meta-651. The monotone model allows two-input AND and OR gates and arbitrary fan-out. The ordinary model in the assignment also allows NOT gates.

## Upper bound

The project-model Lean file `Witnesses.lean` exhibits a 20-gate circuit. The circuit groups the 15 edges into six stars, tests each star, and takes the OR of the six tests. It also gives a 16-gate witness after deleting vertex 0. Both witnesses were checked by Lean 4.36.0.

## Reducing the monotone lower bound to finite cases

Assume there is a monotone circuit of size at most 19. Let the required positive examples be the two-vertex inputs for each edge of the graph. Let the negative examples be its maximal independent sets. Every other input either contains an edge or lies inside a maximal independent set, so every monotone separator of these examples computes the target. Fix a smallest separator.

Suppose a raw AND reads inputs u and v. If their edge is absent from the required positives, this AND is false on all required positives. Replacing it by false preserves acceptance of each required positive. By monotonicity it preserves rejection of every negative. The replacement saves a gate, contradicting minimality.

If their edge is required, put this edge aside and replace the AND by false. Every other required positive remains accepted, and every negative remains rejected. Removing the AND and simplifying one of its readers saves at least two gates. The output cannot be this AND while two or more different edge examples are required. A smallest separator for the residual examples is therefore at least two gates cheaper than the previous budget. We may reconstruct a separator of the original examples by adding the removed edge term with an AND and an OR. Iterate until a minimum residual separator contains only ORs among its gates with two raw inputs. Each step removes one of the 15 distinct edges and spends two of the 19 available gates, so multiple positives remain at every step.

If t edges were put aside, the residual budget is at most 19 − 2t. For a vertex incident to r of these edges, fix its bit to zero. Add back the other t − r removed edges. This gives a circuit of at most 19 − 2r gates for the graph after deleting that vertex. The smaller graph requires 16 binary gates, even with free negations, as checked by `replay_nine.py`. Thus r is at most one and the edges put aside form a matching. The program checks every matching up to the 120 graph automorphisms. For a restriction of a partial problem, adding back each missing edge that survives costs at most two gates. This gives its cofactor lower bound from the full smaller graph.

For the empty matching, all gates with two raw inputs are ORs. If an OR combines adjacent inputs, it can be chosen first. A search at budget 19 eliminates that case. For nonadjacent inputs, either there is exactly one raw OR, or there are at least two. The program tests the one-gate first layer and every orbit of unordered pairs chosen from the 30 nonedges. Any two specified raw ORs can come first in a topological ordering. These cases cover circuits with more than two raw ORs as well.

## Cofactor checks

For a monotone circuit, a signal may be replaced with one that is at least as large on required positives and at most as large on negatives. Every downstream gate preserves both comparisons. The smaller-graph searches measure which one or two designated raw ORs can coexist at the minimum budget. When a cut preserves the designated gates, an impossible minimum pattern raises the lower bound by one. A dead designated gate at minimum size can simply be deleted. The two-gate test requires that neither designated gate is replaceable by a constant or an input, and that the second cannot be replaced by the first. During prefix compaction both designated gates are retained on cuts using this stronger bound.

## Replay

Run `python3 replay_nine.py --monotone` with Python 3.10+ and a C++20 compiler. It works in a temporary directory, rebuilds the small-graph bounds and spectra, then checks the matching cases and all first-layer cases. A completed run exits after validating every required negative search. The computational lower bound and the Lean-checked upper witness have different verification records.
