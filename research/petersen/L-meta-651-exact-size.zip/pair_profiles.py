"""Which pairs of raw OR gates can coexist in a minimum vertex-deleted circuit?"""
from pathlib import Path
from itertools import combinations,product
from collections import defaultdict
import subprocess,json,re,sys
from cofactors import core,automorphisms
from conditioned import image,bound
from root_profiles import translate
from mono_anchors import make
q=Path(__file__).resolve().parent

def seed(mask,budget):
 vertices,edges=core(mask);hits=set()
 for choices in product((0,1),repeat=len(edges)):
    groups=defaultdict(list)
    for (a,b),c in zip(edges,choices):
        if c:a,b=b,a
        groups[a].append(b)
    if len(edges)+len(groups)-1>budget:continue
    raw=[{(*sorted(v),3) for v in combinations(ls,2)} for ls in groups.values()]
    for t,u in combinations(raw,2):
        hits.update(tuple(sorted((a,b))) for a in t for b in u if a!=b)
 return hits

def src():
 s=(q/'boundary.cpp').read_text().replace('if(argc!=5 && argc!=8)', 'if(argc!=11)').replace('if(argc==8)', 'if(argc==11)')
 s=s.replace('bool monotone=false;', 'int second_a=-1,second_b=-1,second_sign=-1;\nbool monotone=false;')
 s=s.replace('  auto start=std::chrono', '  second_a=std::stoi(argv[8]);second_b=std::stoi(argv[9]);second_sign=std::stoi(argv[10]);\n  auto start=std::chrono')
 x='    if(budget==binary_budget && first_a>=0 && (a!=first_a || b!=first_b)) continue;'
 assert x in s
 s=s.replace(x,x+'\n    if(budget==binary_budget-1 && (a!=second_a || b!=second_b)) continue;')
 x='      if(budget==binary_budget && first_a>=0 && inv!=first_sign) continue;'
 s=s.replace(x,x+'\n      if(budget==binary_budget-1 && inv!=second_sign) continue;')
 s=s.replace('int last_new=(budget==binary_budget && first_a>=0)?-1:c;', 'int last_new=budget>=binary_budget-1?-1:c;')
 (q/'tworoot.cpp').write_text(s)

def pairs(mask,budget):
 profile=json.loads((q/('mono-root-profile.json' if mask==1022 else f'profile-{mask}.json')).read_text())
 roots={tuple(map(int,r.split(','))) for r,c in profile.items() if c==budget and r.endswith(',3')}
 group=[p for p in automorphisms() if image(mask,p)==mask]
 todo=set(combinations(sorted(roots),2));valid=seed(mask,budget);assert valid<=todo
 summary={}
 while todo:
    rs=min(todo);orb={tuple(sorted(translate(r,p) for r in rs)) for p in group};todo-=orb
    if orb&valid:result=True;how='star cover'
    else:
        a,b=rs
        if mask==1022:cuts=q/('mono-nine-'+'-'.join(map(str,a))+'.txt')
        else:cuts=q/f'cuts-{mask}.txt'
        if mask==1022 and not cuts.exists():
            base=[tuple(map(int,l.split())) for l in (q/'cuts-1022.txt').read_text().splitlines()]
            cuts=make(mask,a,base,'tworoot-nine-base.txt')
        args=[q/'tworoot',str(budget),str(mask),cuts,'monotone',*map(str,a),*map(str,b)]
        data=subprocess.check_output(args,text=True)
        result=bool(int(re.search(r'found ([01])',data)[1]))
        if result:
            for x in range(1024):
                vals=[bool((x>>k)&1) for k in range(10)]
                for line in data.splitlines()[1:]:
                    k,i,j,inv=map(int,line.split());assert k==len(vals) and inv in (0,3)
                    vals.append((vals[i] or vals[j]) if inv==3 else vals[i] and vals[j])
                assert vals[-1]==any((x>>i)&(x>>j)&1 for i,j in core(mask)[1])
        how=data.splitlines()[0]
    for t in orb:summary[';'.join(','.join(map(str,r)) for r in t)]=result
    print(mask,rs,len(orb),how,flush=True)
    (q/f'mono-pairs-{mask}.json').write_text(json.dumps(summary,sort_keys=True))
if __name__=='__main__':
 src();subprocess.run(['c++','-O3','-std=c++20',q/'tworoot.cpp','-o',q/'tworoot'],check=True)
 for m,k in [(1020,13),(1018,12),(1022,16)]:pairs(m,k)
