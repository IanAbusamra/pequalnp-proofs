"""Validate each cofactor claim used by the final free binary case split."""
from functools import cache
from itertools import combinations
from pathlib import Path
import subprocess,re,sys
from cofactors import automorphisms,core
from conditioned import image,bound
from root_profiles import translate,group
q=Path(__file__).resolve().parent;auto=automorphisms()
@cache
def canonical(mask):return next((m,p) for m in (1022,1020,1018) for p in auto if image(mask,p)==m)
known9={translate((1,2,3),p) for p in auto if p[0]==0}
@cache
def forbidden_single(cut,r,lb):
 if cut&(1<<r[0]|1<<r[1]):return False
 m,p=canonical(1023^cut)
 if m==1022:return translate(r,p) in known9
 return bound(1023,cut,lb,r)>lb
@cache
def pairs_group(m):return tuple(group(m))
@cache
def validate_pair(m,rs,lb):
 # Both required gates have raw operands, so schedule them first.
 a,b=rs
 f=q/(f'cuts-{m}.txt' if m!=1022 else 'dynamic-1022-free.txt')
 if m!=1022:Path(str(f)+'.roots').write_text('')
 args=[q/'exactpair',str(lb),str(m),f,'free',*map(str,a),*map(str,b[:2])]
 data=subprocess.check_output(args,text=True)
 assert 'found 0 ' in data.splitlines()[0],(m,rs,lb,data)
 print('Verified lower bound for first pair',m,rs,lb+1,flush=True)
def assert_extra(cut,roots,lb):
 if any(forbidden_single(cut,r,lb) for r in roots):return
 m,p=canonical(1023^cut)
 survive=[translate(r,p) for r in roots if not cut&(1<<r[0]|1<<r[1])]
 assert len(survive)==2
 rep=min(tuple(sorted(translate(r,g) for r in survive)) for g in pairs_group(m))
 validate_pair(m,rep,lb)
def verify_file(path,roots,check_only=False):
 rows=[tuple(map(int,l.split())) for l in path.read_text().splitlines()]
 assert len(rows)==55 and {c for c,v in rows}=={c for c in range(1,1024) if c.bit_count() in (1,2)}
 lower=[]
 for c,b in rows:
    m,_=canonical(1023^c);lb={1022:16,1020:13,1018:12}[m];lower.append(lb)
    if b!=lb:
        assert b==lb+1
        assert_extra(c,roots,lb)
 for l in Path(str(path)+'.roots').read_text().splitlines():
    a,b,s,bits=map(int,l.split());assert 0<=bits<1<<55
    for i,(cut,v) in enumerate(rows):
        if bits>>i&1:
            assert lower[i]==v and forbidden_single(cut,(a,b,s),v)
 if not check_only:
    r=roots[1] if len(roots)>1 else (-1,-1,3)
    data=subprocess.check_output([q/'freesplit','18','1023',path,'free','0','2','3',str(r[0]),str(r[1])],text=True)
    print(path.name,data.splitlines()[0],flush=True)
    assert 'found 0 ' in data.splitlines()[0]
def main():
 # Make the rooted bounds on the eight- and seven-vertex subgraphs from scratch.
 from dynamic_roots import files
 files(1022,'free')
 edges={tuple(sorted(e)) for e in core(1023)[1]};others={t for t in combinations(range(10),2) if t not in edges}
 def fn(x):return any(x>>a&x>>b&1 for a,b in edges)
 # If v only feeds ORs with one partner or two independent partners, setting all
 # partners true hides v. Exhibit inputs where the target still observes v.
 for v in range(10):
    rest=set(range(10))-{v}
    for k in (1,2):
        for partners in combinations(sorted(rest),k):
            if partners in edges:continue
            assert any(not(x>>v&1) and all(x>>a&1 for a in partners) and not fn(x) and fn(x|1<<v) for x in range(1024))
 root=(0,2,3);opts=[(q/'final-inputs'/'solo.txt',[root])]
 todo=set(combinations(sorted(others),2));assert len(todo)==435
 while todo:
    rs=min(todo);orb={tuple(sorted(tuple(sorted((p[a],p[b]))) for a,b in rs)) for p in auto};todo-=orb
    a,b=min(next(x for x in t if x!=(0,2)) for t in orb if (0,2) in t)
    opts.append((q/'final-inputs'/f'pair-{a}-{b}.txt',[root,(a,b,3)]))
 check_only='--oracles' in sys.argv
 for f,R in opts:verify_file(f,R,check_only)
 if check_only:print('All final-case cofactor inputs validated.',flush=True)
 else:print('No 18-binary-gate Petersen circuit even with free complementation.',flush=True)
if __name__=='__main__':main()
