import Mathlib
import PEqualNP.Defs

namespace PetersenRepair
variable {α : Type*} [PartialOrder α] [Finite α]

/-- A monotone Boolean function is determined by the minimal true assignments and
maximal false assignments of the target. -/
theorem boundary_ext (f k : α → Bool) (hk : Monotone k)
    (hp : ∀ a, Minimal (fun x => f x = true) a → k a = true)
    (hn : ∀ a, Maximal (fun x => f x = false) a → k a = false) :
    k = f := by
  funext x
  cases h : f x with
  | false =>
    obtain ⟨b, hb, hmax⟩ := Finite.exists_le_maximal (p := fun a => f a = false) h
    exact le_antisymm ((hk hb).trans (le_of_eq (hn b hmax))) (by simp)
  | true =>
    obtain ⟨b, hb, hmin⟩ := exists_minimal_le_of_wellFoundedLT (fun a => f a = true) x h
    exact le_antisymm (by simp) ((le_of_eq (hp b hmin).symm).trans (hk hb))

/-- H is the circuit when the output of its sole NOT is exposed as a separate input.
On boundary assignments where H ignores this input, the replacement is unrestricted. -/
theorem repair (f g y : α → Bool) (H : α → Bool → Bool) (hx : Monotone H)
    (hz : ∀ x, Monotone (H x)) (hy : Monotone y) (he : ∀ x, H x (!(g x)) = f x)
    (hp : ∀ x, Minimal (fun a => f a = true) x → H x false ≠ H x true → g x = false → y x = true)
    (hn : ∀ x, Maximal (fun a => f a = false) x → H x false ≠ H x true → g x = true → y x = false) :
    (fun x => H x (y x)) = f := by
  apply boundary_ext
  · intro a b hab
    exact ((hx hab) (y a)).trans (hz b (hy hab))
  · intro x hm
    have e := (he x).trans hm.prop
    by_cases ignored : H x false = H x true
    · cases hg : g x <;> cases hyy : y x <;> simpa [hg,ignored] using e
    cases hg : g x with
    | false => simpa [hp x hm ignored hg,hg] using e
    | true =>
      have h0 : H x false = true := by simpa [hg] using e
      exact le_antisymm (by simp) ((le_of_eq h0.symm).trans (hz x (by simp)))
  · intro x hm
    have e := (he x).trans hm.prop
    by_cases ignored : H x false = H x true
    · cases hg : g x <;> cases hyy : y x <;> simpa [hg,ignored] using e
    cases hg : g x with
    | true => simpa [hn x hm ignored hg,hg] using e
    | false =>
      have h1 : H x true = false := by simpa [hg] using e
      exact le_antisymm ((hz x (by simp)).trans (le_of_eq h1)) (by simp)

/-- A monotone circuit obtained by setting the NOT output false may miss one
edge term. Adding that term repairs it when every other minimal positive is retained. -/
theorem restore_term (f k term : α → Bool) (hk : Monotone k) (ht : Monotone term)
    (hkf : ∀ x, k x ≤ f x) (htf : ∀ x, term x ≤ f x)
    (cover : ∀ x, Minimal (fun a => f a = true) x → k x = true ∨ term x = true) :
    (fun x => k x || term x) = f := by
  apply boundary_ext
  · intro x y h
    exact sup_le_sup (hk h) (ht h)
  · intro x hx
    rcases cover x hx with h | h <;> simp [h]
  · intro x hx
    apply le_antisymm _ (by simp)
    exact (sup_le (hkf x) (htf x)).trans (le_of_eq hx.prop)

open PEqualNP.CircuitLowerBounds

private def run (gs : List Gate) (w : List Bool) : List Bool :=
  gs.foldl (fun a g => a ++ [g.op.eval (g.inputs.map fun i => a.getD i false)]) w

private def ordered (u v : List Bool) : Prop :=
  u.length = v.length ∧ ∀ j, u.getD j false ≤ v.getD j false

private theorem ordered_snoc {u v : List Bool} (h : ordered u v) {a b : Bool} (hab : a ≤ b) :
    ordered (u ++ [a]) (v ++ [b]) := by
  obtain ⟨hl,hg⟩ := h
  refine ⟨by simp [hl], ?_⟩
  intro j
  by_cases hj : j < u.length
  · rw [List.getD_append _ _ _ _ hj,List.getD_append _ _ _ _ (by omega)]
    exact hg j
  · rw [List.getD_append_right _ _ _ _ (by omega), List.getD_append_right _ _ _ _ (by omega),hl]
    cases j - v.length with
    | zero => exact hab
    | succ k => simp

private theorem ordered_gate (g : Gate) (hg : g.op = .and ∨ g.op = .or)
    {u v : List Bool} (h : ordered u v) :
    g.op.eval (g.inputs.map fun i => u.getD i false) ≤
    g.op.eval (g.inputs.map fun i => v.getD i false) := by
  rw [Bool.le_iff_imp]
  rcases hg with ha | ho
  · simp only [ha,GateOp.eval,List.all_eq_true,List.mem_map]
    intro hu b ⟨i,hi,he⟩
    subst b
    exact (Bool.le_iff_imp.mp (h.2 i)) (hu _ ⟨i,hi,rfl⟩)
  · simp only [ho,GateOp.eval,List.any_eq_true,List.mem_map]
    rintro ⟨b,⟨i,hi,he⟩,hb⟩
    refine ⟨_,⟨i,hi,rfl⟩,?_⟩
    exact (Bool.le_iff_imp.mp (h.2 i)) (he.trans hb)

private theorem ordered_run (gs : List Gate) (hg : ∀ g ∈ gs, g.op = .and ∨ g.op = .or)
    {u v : List Bool} (h : ordered u v) : ordered (run gs u) (run gs v) := by
  induction gs generalizing u v with
  | nil => exact h
  | cons g tail ih =>
    apply ih (fun k hk => hg k (by simp [hk]))
    exact ordered_snoc h (ordered_gate g (hg g (by simp)) h)

private theorem ordered_inputs {n : Nat} {x y : Fin n → Bool} (h : x ≤ y) :
    ordered (List.ofFn x) (List.ofFn y) := by
  refine ⟨by simp only [List.length_ofFn], ?_⟩
  intro j
  by_cases hj : j < n
  · rw [List.getD_eq_getElem _ _ (by simpa only [List.length_ofFn] using hj),
        List.getD_eq_getElem _ _ (by simpa only [List.length_ofFn] using hj),
        List.getElem_ofFn,List.getElem_ofFn]
    exact h _
  · rw [List.getD_eq_default _ _ (by simp only [List.length_ofFn]; omega),
        List.getD_eq_default _ _ (by simp only [List.length_ofFn]; omega)]

/-- Expose the unique NOT as a Boolean parameter. The gate lists on either side use the project circuit model. -/
theorem split_single_not {n : Nat} (C : Circuit) (before afterGates : List Gate) (ng : Gate)
    (hlist : C.gates = before ++ ng :: afterGates) (hop : ng.op = .not)
    (hpre : ∀ g ∈ before, g.op = .and ∨ g.op = .or)
    (hpost : ∀ g ∈ afterGates, g.op = .and ∨ g.op = .or) :
    ∃ g : (Fin n → Bool) → Bool, ∃ H : (Fin n → Bool) → Bool → Bool,
      Monotone g ∧ Monotone H ∧ (∀ x, Monotone (H x)) ∧
        ∀ x, C.eval (List.ofFn x) = H x (!(g x)) := by
  let w (x : Fin n → Bool) := run before (List.ofFn x)
  let g (x : Fin n → Bool) := (ng.inputs.map fun i => (w x).getD i false).headD false
  let H (x : Fin n → Bool) (z : Bool) := (run afterGates (w x ++ [z])).getD C.output false
  have pre {x y : Fin n → Bool} (h : x ≤ y) : ordered (w x) (w y) :=
    ordered_run before hpre (ordered_inputs h)
  refine ⟨g,H,?_,?_,?_,?_⟩
  · intro a b hab
    cases hi : ng.inputs with
    | nil => simp [g,hi]
    | cons i tail => simpa only [g,hi,List.map_cons,List.headD_cons] using (pre hab).2 i
  · intro a b hab z
    exact (ordered_run afterGates hpost (ordered_snoc (pre hab) (le_refl z))).2 C.output
  · intro x a b hab
    exact (ordered_run afterGates hpost (ordered_snoc (pre (le_refl x)) hab)).2 C.output
  · intro x
    simp only [Circuit.eval,Circuit.wires,hlist,List.foldl_append,List.foldl_cons,hop,GateOp.eval,H,g,w,run]

end PetersenRepair
#print axioms PetersenRepair.repair

#print axioms PetersenRepair.split_single_not
