"""Test normalized monotone cores after peeling disjoint raw AND terms."""
import sys,itertools,subprocess,re
from pathlib import Path
from cofactors import automorphisms
q=Path(__file__).resolve().parent
edges=[(0,1),(1,2),(2,3),(3,4),(4,0),(0,5),(1,6),(2,7),(3,8),(4,9),(5,7),(7,9),(9,6),(6,8),(8,5)]
es={tuple(sorted(e)):j for j,e in enumerate(edges)}
def orbits(size):
    autos=automorphisms();todo={S for S in itertools.combinations(range(15),size) if len({x for j in S for x in edges[j]})==2*size}
    while todo:
        m=min(todo)
        orb={tuple(sorted(es[tuple(sorted((p[edges[j][0]],p[edges[j][1]])))] for j in m)) for p in autos}
        todo-=orb
        yield m,len(orb)
def main():
 base=[tuple(map(int,s.split())) for s in (q/'mono-cuts-1023.txt').read_text().splitlines()]
 for size in map(int,sys.argv[1:]):
  for S,orb in orbits(size):
    omitted=sum(1<<j for j in S);budget=19-2*size
    edgesets=[(1<<edges[j][0])|(1<<edges[j][1]) for j in S]
    cuts=q/f'partial-cuts-{omitted}.txt'
    with cuts.open('w') as f:
      for cut,lb in base:
        remain=sum(not(cut&e) for e in edgesets)
        lower=lb-2*remain
        if lower>0:f.write(f'{cut} {lower}\n')
    out=q/f'partial-{omitted}.log'
    with out.open('w') as f:subprocess.run([q/'partial',str(budget),'1023',cuts,str(omitted),'1'],stdout=f,check=True)
    print(size,S,orb,out.read_text().splitlines()[0],flush=True)
if __name__=='__main__':main()
