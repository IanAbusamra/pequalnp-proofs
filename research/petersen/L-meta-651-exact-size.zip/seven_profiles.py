from pathlib import Path
from itertools import combinations
import json,re,subprocess
from root_profiles import group,translate
from cofactors import automorphisms,core,orbit
q=Path(__file__).resolve().parent
small={int(k):v for k,v in json.load(open(q/'lower-small.json')).items()}
autos=automorphisms(); masks={m for m in small if m.bit_count()==7}
while masks:
    mask=min(masks);masks-=orbit(mask,autos); vs,E=core(mask)
    cutfile=q/f'cuts-seven-{mask}.txt'
    allv=[i for i in range(10) if mask>>i&1]
    with cutfile.open('w') as f:
        for n in (1,2):
            for e in combinations(allv,n):
                cut=sum(1<<v for v in e);lb=small[mask^cut]
                if lb:f.write(f'{cut} {lb}\n')
    budget=small[mask]
    roots={(*e,s) for e in combinations(vs,2) for s in range(4)}
    gg=list(group(mask));profile={}
    while roots:
        root=min(roots);e={translate(root,p) for p in gg};roots-=e
        r=subprocess.run([q/'bounded',str(budget),str(mask),cutfile,'free',*map(str,root)],text=True,capture_output=True,check=True)
        found=int(re.search(r'found ([01])',r.stdout)[1])
        for x in e:profile[','.join(map(str,x))]=budget+1-found
    (q/f'profile-{mask}.json').write_text(json.dumps(profile,sort_keys=True))
    print('profile',mask,budget,len(profile),flush=True)
